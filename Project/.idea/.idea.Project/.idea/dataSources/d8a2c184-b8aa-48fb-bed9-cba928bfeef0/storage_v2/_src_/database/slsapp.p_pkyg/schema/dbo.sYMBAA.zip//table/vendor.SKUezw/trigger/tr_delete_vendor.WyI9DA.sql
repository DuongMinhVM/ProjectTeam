
Create Trigger tr_Delete_Vendor
On
Vendor
For DELETE
AS
If Exists(Select * from Deleted)
Begin
	Declare @SiteCode as varchar(5)
	Select @SiteCode = value From fpt_MST_SS_Parameters
	Where ID = '005'

	Declare @VendID as varchar(10)
	Select @VendID = VendID from Deleted
	
	If  Not Exists (Select * From fpt_MST_SS_Data_Delete Where Code = Rtrim(@SiteCode)+Rtrim(@VendID) and DataType = 'Vendor')
	Begin
		Insert Into fpt_MST_SS_Data_Delete						
		Values (@SiteCode,'Vendor',Getdate(), Rtrim(@SiteCode)+Rtrim(@VendID) ,0,0,'',Rtrim(@VendID),'','','','')
	End
	Else
	Begin
		Update fpt_MST_SS_Data_Delete Set Status = 0 Where Code = Rtrim(@SiteCode)+Rtrim(@VendID)
	End	
	Update fpt_MST_SS_Data_Baseline Set ProcessType = 'DataDelete' Where Code = Rtrim(@SiteCode)+Rtrim(@VendID) and Status <>2
End
go

