
Create Trigger tr_Update_Customer
On
Customer
For UPDATE,INSERT
AS
If (Update(Addr1) OR Update(Addr2) OR Update(BillAddr1) OR Update(BillAddr2) OR Update(BillName)
	OR Update(Name) OR Update(User1) OR Update(ClassID) OR Update(User5) OR Update(PriceClassID) OR Update(Status) OR Update(Terms))
Begin
	Update Customer Set s4future10 = 0
	Where CustID in (Select CustID from Inserted)
End
go

