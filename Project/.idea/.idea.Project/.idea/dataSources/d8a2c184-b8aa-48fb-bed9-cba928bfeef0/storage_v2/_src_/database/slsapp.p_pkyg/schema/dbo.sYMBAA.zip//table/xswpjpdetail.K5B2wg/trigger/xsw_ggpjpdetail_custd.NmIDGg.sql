
CREATE   trigger xsw_ggPJPDetail_CustD ON [xswPJPDetail] 
for INSERT, UPDATE, DELETE as

set nocount on
set transaction isolation level read uncommitted

delete c 
from deleted d 
left join inserted i on i.CustID = d.CustID and i.ShiptoID = d.ShipToID and i.SlsRouteID = d.SlsRouteID and i.PJPDate = d.PJPDate
inner join xswPJPCustomerD c on c.CustID = d.CustID and c.ShiptoID = d.ShipToID and c.SlsRouteID = d.SlsRouteID and c.PJPDate = d.PJPDate
where d.SchedType = 'R' and (i.PJPDate is null or i.SlsRouteID <> d.SlsRouteID or i.PJPDate <> d.PJPDate)

insert xswPJPCustomerD(CustID, Day1, Day2, Day3, Day4, Day5, Day6, Day7, PJPDate, ShiptoID, SlsRouteID, VisitFreq, VisitWeek)
select i.CustID, c.Day1, c.Day2, c.Day3, c.Day4, c.Day5, c.Day6, c.Day7, i.PJPDate, i.ShipToID, i.SlsRouteID, c.VisitFreq, c.VisitWeek
from inserted i
left join deleted d on i.CustID = d.CustID and i.ShiptoID = d.ShipToID and i.SlsRouteID = d.SlsRouteID and i.PJPDate = d.PJPDate 
inner join xswPJPCustomer c on c.CustID = i.CustID and c.ShiptoID = i.ShipToID 
where i.SchedType = 'R' and (d.PJPDate is null or i.SlsRouteID <> d.SlsRouteID or i.PJPDate <> d.PJPDate)

go

