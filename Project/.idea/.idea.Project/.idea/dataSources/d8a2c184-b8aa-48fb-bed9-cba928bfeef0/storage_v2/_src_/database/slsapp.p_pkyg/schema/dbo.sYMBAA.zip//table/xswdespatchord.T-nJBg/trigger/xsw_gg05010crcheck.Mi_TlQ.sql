

CREATE   TRIGGER xsw_gg05010CrCheck ON dbo.xswDespatchOrd
FOR INSERT, UPDATE AS

declare 
  @procid varchar(5),
  @rowcount smallint, 
  @error smallint,
  @msg_admin_hold smallint,
  @msg_credit_hold smallint,
  @msg_overlimit smallint,
  @msg_overdue smallint,
  @msg_combined smallint,
  @h varchar(16),
  @deleted smallint,
  @inserted smallint

set nocount on


select 
  @inserted = case when exists(select * from inserted) then 1 else 0 end,
  @deleted = case when exists(select * from deleted) then 1 else 0 end,
  @procid = 'xxx.r',
  @h = '0123456789abcdef',
  @msg_admin_hold = 30000,
  @msg_credit_hold = 30001,
  @msg_overlimit = 30002,
  @msg_overdue = 30004,
  @msg_combined = 30006

if @inserted + @deleted = 0 
  return

insert xswwrkprocess (CpnyId, OrderClass, OrderNbr, UserAddress, ProcId, Result, HostId, UserId, 
swfuture1, swfuture2, swfuture3, swfuture4, swfuture5, swfuture6, 
User1, User2, User3, User4, User5, User6, User7, User8)
select i.CpnyID, 'D', i.DespatchNbr, host_name(), @ProcID, 0, host_id(),'',
'', '', '', '', '', '',
'','',0,0,'','','',''
from inserted i
inner loop join xswOrderType y (nolock) on y.OrderType = 'DO' 
left loop join xswwrkprocess w (nolock) on w.cpnyid = i.cpnyid and w.orderclass = 'D' and w.OrderNbr= i.DespatchNbr
where i.UpdProg = y.EditScrnNbr and w.OrderNbr IS NULL  OPTION (FORCE ORDER)
select @error = @@error, @rowcount = @@rowcount	
if @error != 0 return

if update(crtdprog) or update(updprog) or update(status)
if @deleted = 1
update s set 
  s.crtdprog = d.crtdprog,
  s.updprog = i.crtdprog
from inserted i
inner join deleted d on d.CpnyId = i.CpnyId and d.DespatchNbr = i.DespatchNbr
inner join xswDespatchOrd s on s.CpnyId = i.CpnyId and s.DespatchNbr = i.DespatchNbr
where i.CrtdProg != d.CrtdProg
if @@error != 0 return


go

