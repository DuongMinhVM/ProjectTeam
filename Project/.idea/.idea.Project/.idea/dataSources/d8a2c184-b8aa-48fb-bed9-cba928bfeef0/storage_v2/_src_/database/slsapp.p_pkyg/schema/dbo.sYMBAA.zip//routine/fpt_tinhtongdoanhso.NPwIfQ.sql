
CREATE FUNCTION fpt_TinhTongDoanhSo
/*Tinh tong Doanh so ma khach hang da mua trong khoang thoi gian nao do
	- Cac tham so truyen vao:
		+ Khoang thoi gian From_Date, To_date
		+ Ma khach hang
		+ Ma chuong trinh luy ke
	- Gia tri tra ve:
		+ la mot so kieu float
	Author:			Vu Dinh Cuong
	Created date:	28 - Mar - 2007
*/
	(
	@Customer_ID char(15),@ACC_ID varchar(13),
	@From_Date Datetime, @To_Date datetime
	)
RETURNS FLOAT
AS
BEGIN
	DECLARE @TURNOVER FLOAT
	
	DECLARE CursorPrice CURSOR 	FOR 
	select Item_ID from fpt_ShellProduct where ACC_ID = @ACC_ID
	OPEN CursorPrice 
	SET @TURNOVER = 0
	DECLARE @curInvtID char(30),@curPrice float,@curQuantity int,@curTunrover float, @curRejectQuantity int
	fetch next from CursorPrice into @curInvtID
	while @@fetch_status = 0
	BEGIN
	-- LAY TONG DOANH SO MA KHACH HANG DA MUA
	set @curPrice = (select stkBasePrc from Inventory where InvtID = @curInvtID)
	set @curQuantity = (SELECT  SUM(CASE WHEN OrderType IN ('CI', 'IN', 'NP', 'NI') Then LineQty ELSE -1*LineQty end)
			FROM         xswSlsOrdDet
			WHERE    FREEITEM <> 1 AND (CustId = @Customer_ID) AND (OrderDate BETWEEN @From_Date AND @To_date) 
				AND InvtId = @curInvtID)
	IF (@curQuantity IS NULL)
		SET @curQuantity = 0
	SET @curTunrover = @curPrice * @curQuantity
	SET @TURNOVER = @TURNOVER + @curTunrover
	fetch next from CursorPrice into @curInvtID
	END
RETURN @TURNOVER
END
go

