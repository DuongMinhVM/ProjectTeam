
Create Trigger tr_Update_xswSlsRoute
On
xswSlsRoute
For UPDATE,INSERT
AS
If (Update(Name) OR Update(Slsper00) OR Update(Slsper01) OR Update(Slsper02) OR Update(Slsper03) OR Update(Slsper04)
	OR Update(Slsper05) OR Update(Slsper06) OR Update(SlsperID))
Begin
	Update xswSlsRoute set user4 = 0
	Where SlsRouteID in (Select SlsRouteID from Inserted)
End
go

