create trigger xsw_PopulateGroupDiscInt_PG ON [xswDiscItemClass] for INSERT, UPDATE, DELETE as
exec xsw_PopulateGroupDiscInt
go

