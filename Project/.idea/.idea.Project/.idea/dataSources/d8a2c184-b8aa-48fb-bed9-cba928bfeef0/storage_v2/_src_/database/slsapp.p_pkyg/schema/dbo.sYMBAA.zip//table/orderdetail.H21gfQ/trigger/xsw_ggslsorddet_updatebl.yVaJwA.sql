

CREATE    trigger xsw_ggSlsOrdDet_UpdateBL ON [xswSlsOrdDet] 
for INSERT, UPDATE, DELETE 
as

declare 
  @deleted smallint,
  @inserted smallint,
  @BaseDecPl smallint,
  @DecPlQty smallint

set nocount on

select 
  @inserted = case when exists(select * from inserted) then 1 else 0 end,
  @deleted = case when exists(select * from deleted) then 1 else 0 end

if @inserted + @deleted = 0
  return

select
	@BaseDecPl = b.DecPl,
	@DecPlQty = DecPlQty
from GLSetup (nolock)
inner join Currncy b (nolock) on b.CuryID = GLSetup.BaseCuryID
cross join xswSOSetup (nolock)
if @@error <> 0 return

if @inserted = 1
update d
set
  d.OrderDate = so.OrderDate,
  d.CustId = so.CustId,
  d.SlsPerID = so.SlsPerID,
  d.OrderType = so.OrderType,
  d.Status = so.Status,
  d.SWFuture2 = so.ShipComplete,
  d.SWFuture3 = case when y.INDocType = 'NA' and y.ARDocType = 'CM' then 'CM' else y.INDocType end,
  d.CuryInclTaxAmt = round(convert(money,d.CuryInclTaxAmt), c.DecPl),
  d.DspStage = case d.SlsType
    when 'GI' then case 
      when (d.LineQty - d.AltQty) < power(convert(float,0.1), DecPlQty)/2 then 'F' 
      when d.AltQty < power(convert(float,0.1), DecPlQty)/2 then 'N'
      else 'P' end
    when 'MI' then case 
      when (d.CuryLineAmt - d.CuryAltAmt) < power(convert(float,0.1), c.DecPl)/2 then 'F' 
      when d.CuryAltAmt < power(convert(float,0.1), c.DecPl)/2 then 'N'
      else 'P' end
    else d.DspStage end
from 
inserted i
inner loop join xswSlsOrdDet d on d.CpnyId = i.CpnyId and d.OrderNbr = i.OrderNbr and d.LineRef = i.LineRef 
inner loop join xswSalesOrd so on so.CpnyId = i.CpnyId and so.OrderNbr = i.OrderNbr 
inner loop join Currncy c (nolock) on c.CuryID = i.CuryID
inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
cross join xswSOSetup (nolock) OPTION (FORCE ORDER)
if @@error !=0 return

If update(InvtID) or update(SiteID) 
Begin

	/*INSERT missing ItemSite*/
	insert ItemSite(ABCCode, AllocQty, AvgCost, BMIAvgCost, BMIDirStdCst, BMIFOvhStdCst, BMILastCost, BMIPDirStdCst, BMIPFOvhStdCst, BMIPStdCst, 
	BMIPVOvhStdCst, BMIStdCost, BMITotCost, BMIVOvhStdCst, Buyer, COGSAcct, COGSSub, CountStatus, CpnyID, Crtd_DateTime, Crtd_Prog, Crtd_User, 
	CycleID, DfltPOUnit, DfltSOUnit, DirStdCst, EOQ, FOvhStdCst, InvtAcct, InvtID, InvtSub, LastBookQty, LastCost, LastCountDate, 
	LastPurchaseDate, LastPurchasePrice, LastStdCost, LastVarAmt, LastVarPct, LastVarQty, LastVendor, LeadTime, LUpd_DateTime, LUpd_Prog, 
	LUpd_User, MaxOnHand, MfgLeadTime,DfltWhseLoc, MfgClassID, MoveClass, NoteID, PDirStdCst, PFOvhStdCst, PrimVendID, ProdMgrID, PStdCostDate, PStdCst, PVOvhStdCst, 
	QtyAlloc, QtyAvail, QtyCustOrd, QtyInTransit, QtyNotAvail, QtyOnBO, QtyOnDP, QtyOnHand, QtyOnKitAssyOrders, QtyOnPO, QtyOnTransferOrders, 
	QtyShipnotInv, QtyWOFirmDemand, QtyWOFirmSupply, QtyWORlsedDemand, QtyWORlsedSupply, ReordInterval, ReordPt, ReordPtCalc, ReordQty, 
	ReordQtyCalc, ReplMthd, S4Future01, S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09, 
	S4Future10, S4Future11, S4Future12, SafetyStk, SafetyStkCalc, SalesAcct, SalesSub, SecondVendID, Selected, ShipNotInvAcct, ShipNotInvSub, 
	SiteID, StdCost, StdCostDate, StkItem, TotCost, Turns, UsageRate, User1, User2, User3, User4, User5, User6, User7, User8, VOvhStdCst, YTDUsage,
	/*60*/AutoPOPolicy, DfltPickBin, DfltPutAwayBin, DfltRepairBin, DfltVendorBin, IRCalcDailyUsage, IRCalcEOQ, IRCalcLeadTime, IRCalcLinePt, IRCalcRCycDays, 
	IRCalcReOrdPt, IRCalcReOrdQty, IRCalcSafetyStk, IRDailyUsage, IRDaysSupply, IRDemandID, IRFutureDate, IRFuturePolicy, IRLeadTimeID, IRLinePt, IRManualDailyUsage,
	IRManualEOQ, IRManualLeadTime, IRManualLinePt, IRManualRCycDays, IRManualReOrdPt, IRManualReOrdQty, IRManualSafetyStk, IRMaxDailyUsage, IRMaxEOQ, IRMaxLeadTime,
	IRMaxLinePt, IRMaxRCycDays, IRMaxReOrdPt, IRMaxReOrdQty, IRMaxSafetyStk, IRMinDailyUsage, IRMinEOQ, IRMinLeadTime, IRMinLinePt, IRMinOnHand, IRMinRCycDays,
	IRMinReOrdPt, IRMinReOrdQty, IRMinSafetyStk, IRModelInvtID, IRRCycDays, IRSeasonEndDay, IRSeasonEndMon, IRSeasonStrtDay, IRSeasonStrtMon, IRServiceLevel,
	IRSftyStkDays, IRSftyStkPct, IRSftyStkPolicy, IRSourceCode, IRTargetOrdMethod, IRTargetOrdReq, IRTransferSiteID, 
	QtyAllocBM, QtyAllocIN, QtyAllocOther, QtyAllocPORet, QtyAllocSD, QtyAllocSO)
	select v.ABCCode, 0, 0, 0, v.BMIDirStdCost, v.BMIFOvhStdCost, v.BMILastCost, v.BMIPDirStdCost, v.BMIPFOvhStdCost, V.BMIPStdCost, 
	v.BMIPVOvhStdCost, v.BMIStdCost, 0, v.BMIVOvhStdCost, '', v.COGSAcct, V.COGSSub, 'A', i.CpnyID, getdate(), i.CrtdProg, i.CrtdUser, 
	v.CycleID, v.DfltPOUnit, v.DfltSOUnit, v.DirStdCost, 0, v.FOvhStdCost, v.InvtAcct, i.InvtId, v.InvtSub, 0, v.LastCost, '', 
	'', 0, 0, 0, 0, 0, '', 999, getdate(), i.CrtdProg, 
	i.CrtdUser, 0, 0, '','', v.MoveClass, 0, v.PDirStdCost, v.PFOvhStdCost, '', '', v.PStdCostDate, v.PStdCost, v.PVOvhStdCost, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, '', '', '', 0, 0, 0, 0, '', '', 0, 
	0, '', '', 0, 0, v.DfltSalesAcct, v.DfltSalesSub, '', 0, v.DfltShpNotInvAcct, v.DfltShpNotInvSub, 
	i.SiteID, v.StdCost, v.StdCostDate, v.StkItem, 0, 0, v.UsageRate, '', '', 0, 0, '', '', '', '', v.VOvhStdCost, 0,
	/*60*/v.AutoPOPolicy, DfltPickBin='', DfltPutAwayBin='', DfltRepairBin='', DfltVendorBin='', 0, 0, 0, 0, 0, 
	0, 0, 0, 0, v.IRDaysSupply, v.IRDemandID, v.IRFutureDate, v.IRFuturePolicy, v.IRLeadTimeID, v.IRLinePtQty, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, v.IRMinOnHand, 0,
	0, 0, 0, v.IRModelInvtID, v.IRRCycDays, v.IRSeasonEndDay, v.IRSeasonEndMon, v.IRSeasonStrtDay, v.IRSeasonStrtMon, v.IRServiceLevel,
	v.IRSftyStkDays, v.IRSftyStkPct, v.IRSftyStkPolicy, v.IRSourceCode, v.IRTargetOrdMethod, v.IRTargetOrdReq, v.IRTransferSiteID, 
	0, 0, 0, 0, 0, 0
	from 
	(select InvtID, SiteID, CpnyID = max(CpnyID), CrtdProg = max(CrtdProg), CrtdUser = max(CrtdUser) from inserted group by InvtID, SiteID) i
	left loop join ItemSite s on s.InvtId = i.InvtId and s.SiteId = i.SiteId 
	inner join Inventory v (nolock) on v.InvtID = i.InvtID
	where s.InvtId is null OPTION (FORCE ORDER) 
	if @@error !=0 return
End
/*UPDATE ItemSite*/

if update(InvtID) or update(SiteID) or update(status) or update(slsunit) or update(lineqty) or update(altqty) or @deleted > @inserted
update s  
  set 
    s.AllocQty = round(s.AllocQty - coalesce(d.AllocQty,0) + coalesce(i.AllocQty,0), DecPlQty),
    s.QtyAlloc = round(s.AllocQty - coalesce(d.AllocQty,0) + coalesce(i.AllocQty,0), DecPlQty),
    s.QtyCustOrd = round(s.QtyCustOrd - coalesce(d.QtyCustOrd,0) + coalesce(i.QtyCustOrd,0), DecPlQty),
    s.QtyOnBO = round(s.QtyOnBO - coalesce(d.QtyOnBO,0) + coalesce(i.QtyOnBO,0), DecPlQty),
    s.QtyAvail = round(s.QtyOnHand - QtyAllocBM - QtyAllocIN  - QtyAllocOther - QtyAllocPORet - QtyAllocSD - QtyAllocSO
                       + (Case When InclQtyOnPO = 1 Then s.QtyOnPo Else 0 End) 
                       + (Case When InclQtyInTransit = 1 Then s.QtyInTransit + s.QtyOnTransferOrders Else 0 End)                          
                       + (Case When InclQtyOnWO = 1 Then s.QtyOnKitAssyOrders Else 0 End)
                       - (Case When InclQtyCustOrd = 1 Then s.QtyCustOrd - coalesce(d.QtyCustOrd,0) + coalesce(i.QtyCustOrd,0) Else 0 End)
                       - (Case When InclQtyOnBO = 1 Then s.QtyOnBO - coalesce(d.QtyOnBO,0) + coalesce(i.QtyOnBO,0) Else 0 End)
                       - (Case When InclAllocQty = 1 Then s.AllocQty - coalesce(d.AllocQty,0) + coalesce(i.AllocQty,0) Else 0 End)
                       - s.QtyNotAvail 
                       - s.QtyShipNotInv, DecPlQty)
from 
(select cpnyid, invtid, siteid, slstype from deleted union select cpnyid, invtid, siteid, slstype from inserted) v
inner loop join ItemSite s on s.CpnyId = v.CpnyId and s.InvtId = v.InvtId and s.SiteId = v.SiteId
left loop join (select det.CpnyId, InvtId, SiteId, 
           QtyCustOrd = sum(case when unitmultdiv = 'M' then (lineqty - altqty)* unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then (lineqty - altqty) / unitrate
                              else 0 end * st.InclQtyCustOrd),
           QtyOnBO =  sum(case when unitmultdiv = 'M' then (lineqty - altqty) * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then (lineqty - altqty) / unitrate
                              else 0 end * st.InclQtyOnBO * (case when det.SWFuture2 = 'B' then 1 else 0 end)),
           AllocQty = sum(case when unitmultdiv = 'M' then lineqty * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then lineqty / unitrate
                              else 0 end * st.InclQtyAlloc)
           from deleted det
           inner loop join xsworderstatus st (nolock) on st.OrderType = det.OrderType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.OrderType
           where det.slstype = 'GI' and det.SWFuture1 != '1' and y.INDocType not in ('NA','CM','RI')
           group by det.CpnyId, InvtId, SiteId) d on d.CpnyId = v.CpnyId and d.InvtId = v.InvtId and d.SiteId = v.SiteId
left loop join (select det.CpnyId, det.InvtId, det.SiteId, 
           QtyCustOrd = sum(case when unitmultdiv = 'M' then (lineqty - altqty)* unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then (lineqty - altqty) / unitrate
                              else 0 end * st.InclQtyCustOrd),
           QtyOnBO =  sum(case when unitmultdiv = 'M' then (lineqty - altqty) * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then (lineqty - altqty) / unitrate
                              else 0 end * st.InclQtyOnBO * (case when so.ShipComplete = 'B' then 1 else 0 end)),
           AllocQty = sum(case when unitmultdiv = 'M' then lineqty * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then lineqty / unitrate
                              else 0 end *  st.InclQtyAlloc)
           from inserted det
           inner loop join xswSalesOrd so on so.CpnyId = det.CpnyId and so.OrderNbr = det.OrderNbr 
           inner loop join xsworderstatus st (nolock) on st.OrderType = so.OrderType and st.Status = so.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.slstype = 'GI' and det.SWFuture1 != '1' and y.INDocType not in ('NA','CM','RI')
           group by det.CpnyId, det.InvtId, det.SiteId) i on i.CpnyId = v.CpnyId and i.InvtId = v.InvtId and i.SiteId = v.SiteId 
cross join INSetup (nolock)
where v.SlsType = 'GI' and 
  (abs(coalesce(d.AllocQty,0) - coalesce(i.AllocQty,0)) > 0.000000001 or
   abs(coalesce(d.QtyCustOrd,0) - coalesce(i.QtyCustOrd,0)) > 0.000000001 or
   abs(coalesce(d.QtyOnBO,0) - coalesce(i.QtyOnBO,0)) > 0.00000001)
OPTION (FORCE ORDER) 
if @@error !=0 return

/*UPDATE Blanket details*/
if update(altordernbr) or update(altlineref) or update(status) or update (lineqty) or @deleted > @inserted
UPDATE s
set 
  s.altqty = s.altqty - case when y.INDocType = 'NA' then (coalesce(d.lineqty,0) - coalesce(i.lineqty,0)) else 0 end,
  s.openqty = s.openqty - case when y.INDocType = 'TR' then (coalesce(d.lineqty,0) - coalesce(i.lineqty,0)) else 0 end,
  s.dspstage = case s.SlsType
  when 'GI' then case 
    when y.INDocType = 'TR' then s.DspStage 
    when (s.LineQty - (s.AltQty - coalesce(d.lineqty,0) + coalesce(i.lineqty,0))) < power(convert(float,0.1), DecPlQty)/2 then 'F'
    when (s.AltQty - coalesce(d.lineqty,0) + coalesce(i.lineqty,0)) < power(convert(float,0.1), DecPlQty)/2 then 'N'
    else 'P' end
  when 'MI' then case 
    when (s.CuryLineAmt - (s.CuryAltAmt - coalesce(d.curylineamt,0) + coalesce(i.curylineamt,0))) < power(convert(float,0.1), c.DecPl)/2 then 'F' 
    when (s.CuryAltAmt - coalesce(d.curylineamt,0) + coalesce(i.curylineamt,0)) < power(convert(float,0.1), c.DecPl)/2 then 'N'
    else 'P' end
  else s.DspStage end
from 
     (select CpnyId, AltOrderNbr, AltLineRef from deleted  where AltLineRef != ''
union select CpnyId, AltOrderNbr, AltLineRef from inserted where AltLineRef != '') v
inner loop join xswSlsOrdDet s on s.CpnyId = v.CpnyId and s.OrderNbr = v.AltOrderNbr and s.LineRef = v.AltLineRef
inner loop join xswOrderType y (nolock) on y.OrderType = s.OrderType and y.ARDocType = 'NA' and y.INDocType IN ('TR','NA')
left loop join inserted i on i.CpnyId = s.CpnyId and i.AltOrderNbr = s.OrderNbr and i.AltLineRef = s.LineRef and i.Status != 'L'
left loop join deleted d on d.CpnyId = s.CpnyId and d.AltOrderNbr = s.OrderNbr and d.AltLineRef = s.LineRef and d.Status != 'L'
inner loop join Currncy c (nolock) on c.CuryID = s.CuryID
cross join xswSOSetup (nolock) OPTION (FORCE ORDER) 
if @@error !=0 return

/*UPDATE Blanket Status*/
if update(altordernbr) or update(altlineref) 
UPDATE s set 
  status = case when v.MinStage = v.MaxStage and v.MaxStage = 'F' then 'C' else 'O' end,
  PerClosed = case when v.MinStage = v.MaxStage and v.MaxStage = 'F' then PerNbr else '' end
from 
(select v.CpnyId, OrderNbr = v.AltOrderNbr, MinStage=min(s.dspstage), MaxStage=max(s.dspstage)
 from (      select distinct CpnyId, AltOrderNbr from deleted  where AltLineRef != ''
      union  select distinct CpnyId, AltOrderNbr from inserted where AltLineRef != '') v
      inner loop join xswSlsOrdDet s 
      on s.CpnyId = v.CpnyId and s.OrderNbr = v.AltOrderNbr and s.OrderType = 'BL' and SlsType = 'GI'
      group by v.CpnyId, v.AltOrderNbr) v 
inner join xswSalesOrd s on s.cpnyid = v.cpnyid and s.ordernbr = v.ordernbr
cross join xswSOSetup (nolock)
if @@error !=0 return

if update(SlsPerID) or update(BudgetIDC1) or update(DiscAmtC1) or update(Status) or @deleted > @inserted
update s set 
    s.QtyAmtSpent = round(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0), @BaseDecPl),
    s.QtyAmtAvail = round(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0), @BaseDecPl)
from 
(select SlsPerID, BudgetIDC1 from deleted union select SlsPerID, BudgetIDC1 from inserted) v
inner loop join xswDiscAlloc s on s.SlsPerID = v.SlsPerID and s.BudgetID = v.BudgetIDC1
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from deleted det
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = det.OrderType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) d on d.SlsPerID = v.SlsPerID and d.BudgetIDC1 = v.BudgetIDC1
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from inserted det
           inner loop join xswSalesOrd so on so.CpnyId = det.CpnyId and so.OrderNbr = det.OrderNbr 
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = so.OrderType and st.Status = so.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) i on i.SlsPerID = v.SlsPerID and i.BudgetIDC1 = v.BudgetIDC1
where (abs(coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) >= 0.00005)
OPTION (FORCE ORDER) 
if @@error <> 0 return

if update(SlsPerID) or update(BudgetIDC2) or update(DiscAmtC2) or update(Status) or @deleted > @inserted
update s set 
    s.QtyAmtSpent = round(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0), @BaseDecPl),
    s.QtyAmtAvail = round(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0), @BaseDecPl)
from 
(select SlsPerID, BudgetIDC2 from deleted union select SlsPerID, BudgetIDC2 from inserted) v
inner loop join xswDiscAlloc s on s.SlsPerID = v.SlsPerID and s.BudgetID = v.BudgetIDC2
left loop join (select det.SlsPerID, det.BudgetIDC2, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from deleted det
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = det.OrderType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC2) d on d.SlsPerID = v.SlsPerID and d.BudgetIDC2 = v.BudgetIDC2
left loop join (select det.SlsPerID, det.BudgetIDC2, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from inserted det
           inner loop join xswSalesOrd so on so.CpnyId = det.CpnyId and so.OrderNbr = det.OrderNbr 
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = so.OrderType and st.Status = so.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC2) i on i.SlsPerID = v.SlsPerID and i.BudgetIDC2 = v.BudgetIDC2
where (abs(coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) >= 0.00005)
OPTION (FORCE ORDER) 
if @@error <> 0 return

/*Manual FreeItems*/
if update(SlsPerID) or update(BudgetIDC1) or update(LineQty) or update(FreeItem) or update(Status) or @deleted > @inserted
update s set 
    s.QtyAmtSpent = round(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0), @DecPlQty),
    s.QtyAmtAvail = round(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0), @DecPlQty),
	s.MUOMQtySpent = 
		coalesce(nullif(left(sign(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)),1),'1'),'')+
		coalesce(convert(varchar, floor(abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) * NCnvFact3)) + '/','') + 
		coalesce(convert(varchar, floor((abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * NCnvFact2)) + '/', '') +
		convert(varchar, abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) - CnvFact2 * floor((abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * RCnvFact2)),
	s.MUOMQtyAvail = 
		coalesce(nullif(left(sign(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)),1),'1'),'')+
		coalesce(convert(varchar, floor(abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) * NCnvFact3)) + '/','') + 
		coalesce(convert(varchar, floor((abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * NCnvFact2)) + '/', '') +
		convert(varchar, abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) - CnvFact2 * floor((abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * RCnvFact2)) 
from 
(select SlsPerID, BudgetIDC1 from deleted union select SlsPerID, BudgetIDC1 from inserted) v
inner loop join xswDiscAlloc s on s.SlsPerID = v.SlsPerID and s.BudgetID = v.BudgetIDC1
inner join xsw_vpInvtConvUnit u2 (nolock) on u2.InvtID = s.FreeItemID
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(case when det.UnitMultDiv = 'M' then det.LineQty * det.UnitRate when det.UnitRate <> 0 then det.LineQty / det.UnitRate else 0 end * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from deleted det
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = det.OrderType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 1 and det.LineRef like '[0-9]%' and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) d on d.SlsPerID = v.SlsPerID and d.BudgetIDC1 = v.BudgetIDC1
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(case when det.UnitMultDiv = 'M' then det.LineQty * det.UnitRate when det.UnitRate <> 0 then det.LineQty / det.UnitRate else 0 end * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from inserted det
           inner loop join xswSalesOrd so on so.CpnyId = det.CpnyId and so.OrderNbr = det.OrderNbr 
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = so.OrderType and st.Status = so.Status
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 1 and det.LineRef like '[0-9]%' and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) i on i.SlsPerID = v.SlsPerID and i.BudgetIDC1 = v.BudgetIDC1
where (abs(coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) >= 0.00005)
OPTION (FORCE ORDER)


go

