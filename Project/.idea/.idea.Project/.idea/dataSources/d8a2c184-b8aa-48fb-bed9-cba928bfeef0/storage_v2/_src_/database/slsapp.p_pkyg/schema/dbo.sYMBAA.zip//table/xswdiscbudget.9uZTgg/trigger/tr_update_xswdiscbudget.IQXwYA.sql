
Create Trigger tr_Update_xswDiscBudget
On
xswDiscBudget
For UPDATE,INSERT
AS
If (Update(Descr) OR Update(QtyAmtAlloc) OR Update(QtyAmtFree) 
	OR Update(QtyAmtTotal)OR Update(ApplyTo) OR Update(FreeItemID))
Begin
	
	Update xswDiscBudget set user4 =0
	Where BudgetID in (Select BudgetID from Inserted)
End
go

