
create trigger xsw_ggSyncSiteInventoryAcct ON Site FOR UPDATE
AS
set nocount on
If Update(DfltInvtAcct) 
Begin 
Update I set InvtAcct = ins.DfltInvtAcct
from ItemSite I inner join inserted ins on I.SiteID = Ins.SiteID
Where ABS(I.QtyOnHand) < 0.001
End
go

