create trigger xsw_PopulateGroupDiscInt_II ON [xswDiscItem] for INSERT, UPDATE, DELETE as
exec xsw_PopulateGroupDiscInt
go

