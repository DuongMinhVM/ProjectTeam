
-- Create trigger update sales price
create trigger trg_fpt_UpdateTax  
on xswSalesPrice  
after update
as  
update xswSalesPrice  
set TaxID = 'VAT10',  
  TaxRate = 10  
where InvtID in  
(  
  select InvtID  
  from inserted  
)
go

