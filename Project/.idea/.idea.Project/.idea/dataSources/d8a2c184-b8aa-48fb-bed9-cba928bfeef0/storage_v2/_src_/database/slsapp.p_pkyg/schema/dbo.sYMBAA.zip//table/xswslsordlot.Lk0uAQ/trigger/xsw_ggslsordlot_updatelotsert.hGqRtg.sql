
CREATE    TRIGGER xsw_ggSlsOrdLot_UpdateLotSerT ON dbo.xswslsordlot
FOR INSERT, UPDATE, DELETE
AS

declare
  @deleted smallint,
  @inserted smallint

set nocount on

select 
  @inserted = case when exists(select * from inserted) then 1 else 0 end,
  @deleted = case when exists(select * from deleted) then 1 else 0 end

if @inserted + @deleted = 0
  return

If update(OrderType) or Update(Status)
BEGIN
  update lot
  set
    lot.OrderType = so.OrderType,
    lot.Status = so.Status
  from 
  inserted i
  inner loop join xswSlsOrdLot lot on lot.CpnyId = i.CpnyId and lot.OrderNbr = i.OrderNbr and lot.LineRef = i.LineRef and lot.WhseLoc = i.WhseLoc and lot.LotSerNbr = i.LotSerNbr and lot.SpecificCostID = i.SpecificCostID
  inner loop join xswSalesOrd so on so.CpnyId = i.CpnyId and so.OrderNbr = i.OrderNbr 
  if @@error !=0 return
END

/*UPDATE LotSerMst*/
if update(InvtID) or update(SiteID) or update(whseloc) or update(lotsernbr) or update(status) or update(slsunit) or update(qty) or @deleted > @inserted
update m set 
	m.QtyAlloc = round(m.QtyAlloc - coalesce(d.QtyAlloc,0) + coalesce(i.QtyAlloc,0), DecPlQty),
	m.QtyAllocSO = round(m.QtyAllocSO - coalesce(d.QtyAllocSO,0) + coalesce(i.QtyAllocSO,0), DecPlQty),
    m.QtyAvail = round(m.QtyOnHand - QtyAllocBM - QtyAllocIN  - QtyAllocOther - QtyAllocPORet - QtyAllocSD - m.QtyAllocSO + coalesce(d.QtyAllocSO,0) - coalesce(i.QtyAllocSO,0)
                       - (Case When InclAllocQty = 1 Then m.QtyAlloc - coalesce(d.QtyAlloc,0) + coalesce(i.QtyAlloc,0) Else 0 End)
                       - m.QtyShipNotInv, DecPlQty)
from 
(select invtid, siteid, whseloc, lotsernbr from deleted union select invtid, siteid, whseloc,lotsernbr from inserted) v
inner loop join LotSerMst m on m.InvtId = v.InvtId and m.SiteID = v.SiteID and m.WhseLoc = v.WhseLoc and m.LotSerNbr = v.LotSerNbr
left loop join (select lot.InvtId, lot.SiteId, lot.WhseLoc, lot.LotSerNbr,
           QtyAlloc = sum(qty * st.InclQtyAlloc),
           QtyAllocSO = sum(qty * st.InclQtyCustOrd)
           from deleted lot
           inner loop join xswOrderStatus st (nolock) on st.OrderType = lot.OrderType and st.Status = lot.Status
           inner loop join xswOrderType y (nolock) on y.OrderType = lot.OrderType
           where y.INDocType not in ('NA','CM','RI')
           group by lot.InvtId, lot.SiteId, lot.WhseLoc, lot.LotSerNbr) d on d.InvtId = m.InvtId and d.SiteId = m.SiteId and d.WhseLoc = m.WhseLoc and d.LotSerNbr = m.LotSerNbr
left loop join (select lot.InvtId, lot.SiteId, lot.WhseLoc, lot.LotSerNbr,
           QtyAlloc = sum(qty * st.InclQtyAlloc),
           QtyAllocSO = sum(qty * st.InclQtyCustOrd)
           from inserted lot
           inner loop join xswSalesOrd so on so.CpnyId = lot.CpnyId and so.OrderNbr = lot.OrderNbr
           inner loop join xswOrderStatus st (nolock) on st.OrderType = so.OrderType and st.Status = so.Status
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where y.INDocType not in ('NA','CM','RI')
           group by lot.InvtId, lot.SiteId, lot.WhseLoc, lot.LotSerNbr) i on i.InvtId = m.InvtId and i.SiteId = m.SiteId and i.WhseLoc = m.WhseLoc and i.LotSerNbr = m.LotSerNbr
cross join INSetup (nolock) 
where 
	abs(coalesce(d.QtyAlloc,0) - coalesce(i.QtyAlloc,0)) > 0.0000001 or 
	abs(coalesce(d.QtyAllocSO,0) - coalesce(i.QtyAllocSO,0)) > 0.0000001
OPTION (FORCE ORDER) 

if @@error !=0 return

/*INSERT missing xswLocation*/
If Update (InvtId) or Update(SiteId) or Update(WhseLoc)
BEGIN 
  insert xswlocation(InvtId, SiteId, WhseLoc, QtyAvail, QtyOnHand, QtyCustOrd, QtyOnBO, QtyAlloc, QtyShipNotInv, QtyWORlsedDemand, MessageID, 
  SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6, User1, User2, User3, User4, User5, User6, User7, User8)
  select v.InvtId, v.SiteId, v.WhseLoc, 0, 0, 0, 0, 0, 0, 0, 0, 
  '', '', '', '', v.CpnyID, '', '', '', 0, 0, v.CrtdProg, v.CrtdUser, '', ''
  from
  (select distinct lot.InvtId, lot.SiteId, lot.WhseLoc, CpnyId = max(lot.CpnyID), CrtdProg=max(lot.CrtdProg), CrtdUser = max(lot.CrtdUser)
           from inserted lot
           inner loop join xswSalesOrd so on so.CpnyId = lot.CpnyId and so.OrderNbr = lot.OrderNbr 
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where y.INDocType not in ('NA','CM','RI')
           group by lot.InvtId, lot.SiteId, lot.WhseLoc) v
   left loop join xswLocation l on l.InvtId = v.InvtId and l.SiteId = v.SiteId and l.WhseLoc = v.WhseLoc
   where l.InvtId is null OPTION (FORCE ORDER)
   if @@error !=0 return
END

/*UPDATE xswLocation*/
if update(InvtID) or update(SiteID) or update(whseloc) or update(status) or update(slsunit) or update(qty) or @deleted > @inserted
update l
  set 
    l.QtyCustOrd = round(l.QtyCustOrd - coalesce(d.QtyCustOrd,0) + coalesce(i.QtyCustOrd,0), DecPlQty),
    l.QtyAlloc = round(l.QtyAlloc - coalesce(d.QtyAlloc,0) + coalesce(i.QtyAlloc,0), DecPlQty),
    l.QtyOnBO = round(l.QtyOnBO - coalesce(d.QtyOnBO,0) + coalesce(i.QtyOnBO,0), DecPlQty),
    l.QtyAvail = round(l.QtyOnHand 
                       - (Case When InclQtyCustOrd = 1 Then l.QtyCustOrd - coalesce(d.QtyCustOrd,0) + coalesce(i.QtyCustOrd,0) Else 0 End)
                       - (Case When InclQtyOnBO = 1 Then l.QtyOnBO - coalesce(d.QtyOnBO,0) + coalesce(i.QtyOnBO,0) Else 0 End)
                       - (Case When InclAllocQty = 1 Then l.QtyAlloc - coalesce(d.QtyAlloc,0) + coalesce(i.QtyAlloc,0)  Else 0 End)
                       - l.QtyShipNotInv, DecPlQty)
from 
(select invtid, siteid, whseloc from deleted union select invtid, siteid, whseloc from inserted) v
inner loop join xswLocation l on l.InvtId = v.InvtId and l.SiteID = v.SiteID and l.WhseLoc = v.WhseLoc
left loop join (select lot.InvtId, lot.SiteId, lot.WhseLoc,
           QtyCustOrd =    sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyCustOrd),
           QtyOnBO =       0, --sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyOnBO),
           QtyAlloc =      sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyAlloc),
           QtyShipNotInv = sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyShipNotInv)
           from deleted lot
           inner loop join xswOrderStatus st (nolock) on st.OrderType = lot.OrderType and st.Status = lot.Status
           inner loop join xswOrderType y (nolock) on y.OrderType = lot.OrderType
           where lot.SWFuture1 != '1' and y.INDocType not in ('NA','CM','RI')
           group by lot.InvtId, lot.SiteId, lot.WhseLoc) d on d.InvtId = l.InvtId and d.SiteId = l.SiteId and d.WhseLoc = l.WhseLoc
left loop join (select lot.InvtId, lot.SiteId, lot.WhseLoc,
           QtyCustOrd =    sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyCustOrd),
           QtyOnBO =       0, --sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyOnBO),
           QtyAlloc =      sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyAlloc),
           QtyShipNotInv = sum(qty * (case when unitmultdiv = 'M' then unitrate when unitrate != 0 then 1/unitrate else 0 end) * st.InclQtyShipNotInv)
           from inserted lot
           inner loop join xswSalesOrd so on so.CpnyId = lot.CpnyId and so.OrderNbr = lot.OrderNbr
           inner loop join xswOrderStatus st (nolock) on st.OrderType = so.OrderType and st.Status = so.Status
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where lot.SWFuture1 != '1' and y.INDocType not in ('NA','CM','RI')
           group by lot.InvtId, lot.SiteId, lot.WhseLoc) i on i.InvtId = l.InvtId and i.SiteId = l.SiteId and i.WhseLoc = l.WhseLoc 
cross join INSetup (nolock) 
where (abs(coalesce(d.QtyCustOrd,0) - coalesce(i.QtyCustOrd,0)) > 0.0000001 or
       abs(coalesce(d.QtyAlloc,0) - coalesce(i.QtyAlloc,0)) > 0.0000001 or
       abs(coalesce(d.QtyOnBO,0) - coalesce(i.QtyOnBO,0)) > 0.0000001)
OPTION (FORCE ORDER) 
if @@error !=0 return


go

