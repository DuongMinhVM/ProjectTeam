
create trigger xsw_ggSyncInventoryAcct ON ProductClass FOR UPDATE

AS

set nocount on
If Update(DfltInvtAcct) or  Update(DfltInvtSub) 
Begin 
Update I set InvtAcct = ins.DfltInvtAcct, InvtSub = ins.DfltInvtSub
from inserted ins inner join Inventory T on ins.ClassID = T.ClassID
inner join ItemSite I on I.INvtID = T.INvtID
inner join Site S on I.SiteID = S.SiteID and s.DfltInvtAcct = ''
Where ABS(I.QtyOnHand) < 0.001

Update T set InvtAcct = ins.DfltInvtAcct, InvtSub = ins.DfltInvtSub
from inserted ins inner join Inventory T on ins.ClassID = T.ClassID 

End
go

