Create trigger xsw_ggINsetup01 on INsetup for INSERT, UPDATE as
if update(inclqtycustord) begin
  If (select top 1 inclqtycustord from  inserted) = 1 begin
  update INsetup set inclqtyonbo = 1, inclallocqty = 1
  end
end
go

