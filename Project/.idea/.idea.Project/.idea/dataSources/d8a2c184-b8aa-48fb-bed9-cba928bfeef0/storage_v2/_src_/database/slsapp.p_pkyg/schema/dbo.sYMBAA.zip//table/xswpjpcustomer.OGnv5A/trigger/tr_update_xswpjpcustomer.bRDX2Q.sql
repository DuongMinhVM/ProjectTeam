
Create Trigger tr_Update_xswPJPCustomer
On
xswPJPCustomer
For UPDATE,INSERT
AS
If (Update(Active) OR  Update(slsRouteID) OR Update(VisitFreq)OR Update(VisitWeek) OR Update(DelivSeq)
OR Update(Day1)OR Update(Day2)OR Update(Day3)OR Update(Day4)OR Update(Day5)OR Update(Day6)OR Update(Day7))

Begin
	Declare @CustID as varchar(10)
	Declare @ShiptoID as varchar(5)
	Select @CustID=CustID, @ShiptoID=ShipToID from Inserted

	
	Update xswPJPCustomer set user4 = 0
	Where CustID = @CustID and ShipToID = @ShiptoID	
	
End
go

