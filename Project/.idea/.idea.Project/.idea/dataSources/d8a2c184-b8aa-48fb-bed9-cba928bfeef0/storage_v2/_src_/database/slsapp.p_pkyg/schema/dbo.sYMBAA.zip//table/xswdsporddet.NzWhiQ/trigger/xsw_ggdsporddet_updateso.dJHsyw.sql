
CREATE  trigger xsw_ggDspOrdDet_UpdateSO ON [xswDspOrdDet] 
for INSERT, UPDATE, DELETE 
as

declare
  @deleted smallint,
  @inserted smallint,
  @BaseDecPl smallint,
  @DecPlQty smallint,
  @DespatchType char(2)

set nocount on

/* Optimized for Kalido interface
--ABoykov: commented out due to schema changes and unclear idea
if (
	( substring(columns_updated(),  1, 1) ) = 0 AND
	( substring(columns_updated(),  2, 1) ) = 0 AND
	( substring(columns_updated(),  3, 1) ) = 0 AND
	( substring(columns_updated(),  4, 1) ) = 0 AND
	( substring(columns_updated(),  5, 1) ) = 0 AND
	( substring(columns_updated(),  6, 1) ) = 0 AND
	( substring(columns_updated(),  7, 1) ) = 0 AND
	( substring(columns_updated(),  8, 1) ) = 0 AND
	( substring(columns_updated(),  9, 1) ) = 0 AND
	( substring(columns_updated(), 10, 1) ) = 0 AND
	( substring(columns_updated(), 11, 1) ) = 0 AND
	( substring(columns_updated(), 12, 1) ) = 0 AND
	( substring(columns_updated(), 13, 1) & 5 ) = 0
)
	return
*/

select 
  @inserted = case when exists(select * from inserted) then 1 else 0 end,
  @deleted = case when exists(select * from deleted) then 1 else 0 end

if @inserted + @deleted = 0
  return

select
	@BaseDecPl = b.DecPl,
	@DecPlQty = DecPlQty,
	@DespatchType = 'DO'
from GLSetup (nolock)
inner join Currncy b (nolock) on b.CuryID = GLSetup.BaseCuryID
cross join xswSOSetup (nolock)
if @@error <> 0 return

if @inserted = 1
update d set
  --must be set directly 
  d.OrderDate = so.OrderDate,
  d.SOType = so.OrderType,
  d.Status = so.SWFuture1
from 
inserted i
inner loop join xswDspOrdDet d on d.CpnyId = i.CpnyId and d.DespatchNbr = i.DespatchNbr and d.AltOrderNbr = i.AltOrderNbr and d.LineRef = i.LineRef 
inner loop join xswSlsOrdDsp so on so.CpnyId = i.CpnyId and so.DespatchNbr = i.DespatchNbr and so.OrderNbr = i.AltOrderNbr 
OPTION(FORCE ORDER) 
if @@error !=0 return 

If update(InvtID) or update(SiteID) 
BEGIN
	/*INSERT missing ItemSite*/
	insert ItemSite(ABCCode, AllocQty, AvgCost, BMIAvgCost, BMIDirStdCst, BMIFOvhStdCst, BMILastCost, BMIPDirStdCst, BMIPFOvhStdCst, BMIPStdCst, 
	BMIPVOvhStdCst, BMIStdCost, BMITotCost, BMIVOvhStdCst, Buyer, COGSAcct, COGSSub, CountStatus, CpnyID, Crtd_DateTime, Crtd_Prog, Crtd_User, 
	CycleID, DfltPOUnit, DfltSOUnit, DirStdCst, EOQ, FOvhStdCst, InvtAcct, InvtID, InvtSub, LastBookQty, LastCost, LastCountDate, 
	LastPurchaseDate, LastPurchasePrice, LastStdCost, LastVarAmt, LastVarPct, LastVarQty, LastVendor, LeadTime, LUpd_DateTime, LUpd_Prog, 
	LUpd_User, MaxOnHand, MfgLeadTime, DfltWhseLoc, MfgClassID, MoveClass, NoteID, PDirStdCst, PFOvhStdCst, PrimVendID, ProdMgrID, PStdCostDate, PStdCst, PVOvhStdCst, 
	QtyAlloc, QtyAvail, QtyCustOrd, QtyInTransit, QtyNotAvail, QtyOnBO, QtyOnDP, QtyOnHand, QtyOnKitAssyOrders, QtyOnPO, QtyOnTransferOrders, 
	QtyShipnotInv, QtyWOFirmDemand, QtyWOFirmSupply, QtyWORlsedDemand, QtyWORlsedSupply, ReordInterval, ReordPt, ReordPtCalc, ReordQty, 
	ReordQtyCalc, ReplMthd, S4Future01, S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09, 
	S4Future10, S4Future11, S4Future12, SafetyStk, SafetyStkCalc, SalesAcct, SalesSub, SecondVendID, Selected, ShipNotInvAcct, ShipNotInvSub, 
	SiteID, StdCost, StdCostDate, StkItem, TotCost, Turns, UsageRate, User1, User2, User3, User4, User5, User6, User7, User8, VOvhStdCst, YTDUsage,
	/*60*/AutoPOPolicy, DfltPickBin, DfltPutAwayBin, DfltRepairBin, DfltVendorBin, IRCalcDailyUsage, IRCalcEOQ, IRCalcLeadTime, IRCalcLinePt, IRCalcRCycDays, 
	IRCalcReOrdPt, IRCalcReOrdQty, IRCalcSafetyStk, IRDailyUsage, IRDaysSupply, IRDemandID, IRFutureDate, IRFuturePolicy, IRLeadTimeID, IRLinePt, IRManualDailyUsage,
	IRManualEOQ, IRManualLeadTime, IRManualLinePt, IRManualRCycDays, IRManualReOrdPt, IRManualReOrdQty, IRManualSafetyStk, IRMaxDailyUsage, IRMaxEOQ, IRMaxLeadTime,
	IRMaxLinePt, IRMaxRCycDays, IRMaxReOrdPt, IRMaxReOrdQty, IRMaxSafetyStk, IRMinDailyUsage, IRMinEOQ, IRMinLeadTime, IRMinLinePt, IRMinOnHand, IRMinRCycDays,
	IRMinReOrdPt, IRMinReOrdQty, IRMinSafetyStk, IRModelInvtID, IRRCycDays, IRSeasonEndDay, IRSeasonEndMon, IRSeasonStrtDay, IRSeasonStrtMon, IRServiceLevel,
	IRSftyStkDays, IRSftyStkPct, IRSftyStkPolicy, IRSourceCode, IRTargetOrdMethod, IRTargetOrdReq, IRTransferSiteID, 
	QtyAllocBM, QtyAllocIN, QtyAllocOther, QtyAllocPORet, QtyAllocSD, QtyAllocSO)
	select v.ABCCode, 0, 0, 0, v.BMIDirStdCost, v.BMIFOvhStdCost, v.BMILastCost, v.BMIPDirStdCost, v.BMIPFOvhStdCost, V.BMIPStdCost, 
	v.BMIPVOvhStdCost, v.BMIStdCost, 0, v.BMIVOvhStdCost, '', v.COGSAcct, V.COGSSub, 'A', i.CpnyID, getdate(), i.CrtdProg, i.CrtdUser, 
	v.CycleID, v.DfltPOUnit, v.DfltSOUnit, v.DirStdCost, 0, v.FOvhStdCost, v.InvtAcct, i.InvtId, v.InvtSub, 0, v.LastCost, '', 
	'', 0, 0, 0, 0, 0, '', 999, getdate(), i.CrtdProg, 
	i.CrtdUser, 0, 0, '','', v.MoveClass, 0, v.PDirStdCost, v.PFOvhStdCost, '', '', v.PStdCostDate, v.PStdCost, v.PVOvhStdCost, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, 0, 0, 0, 0, 0, 0, 0, 0, 
	0, '', '', '', 0, 0, 0, 0, '', '', 0, 
	0, '', '', 0, 0, v.DfltSalesAcct, v.DfltSalesSub, '', 0, v.DfltShpNotInvAcct, v.DfltShpNotInvSub, 
	i.SiteID, v.StdCost, v.StdCostDate, v.StkItem, 0, 0, v.UsageRate, '', '', 0, 0, '', '', '', '', v.VOvhStdCost, 0,
	/*60*/v.AutoPOPolicy, DfltPickBin='', DfltPutAwayBin='', DfltRepairBin='', DfltVendorBin='', 0, 0, 0, 0, 0, 
	0, 0, 0, 0, v.IRDaysSupply, v.IRDemandID, v.IRFutureDate, v.IRFuturePolicy, v.IRLeadTimeID, v.IRLinePtQty, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, v.IRMinOnHand, 0,
	0, 0, 0, v.IRModelInvtID, v.IRRCycDays, v.IRSeasonEndDay, v.IRSeasonEndMon, v.IRSeasonStrtDay, v.IRSeasonStrtMon, v.IRServiceLevel,
	v.IRSftyStkDays, v.IRSftyStkPct, v.IRSftyStkPolicy, v.IRSourceCode, v.IRTargetOrdMethod, v.IRTargetOrdReq, v.IRTransferSiteID, 
	0, 0, 0, 0, 0, 0
	from 
	(select InvtID, SiteID, CpnyID = max(CpnyID), CrtdProg = max(CrtdProg), CrtdUser = max(CrtdUser) from inserted group by InvtID, SiteID) i
	left loop join ItemSite s on s.InvtId = i.InvtId and s.SiteId = i.SiteId 
	inner join Inventory v (nolock) on v.InvtID = i.InvtID
	where s.InvtId is null OPTION (FORCE ORDER) 
	if @@error !=0 return
END

/*UPDATE ItemSite*/
if update(InvtID) or update(SiteID) or update(status) or update(slsunit) or update(lineqty) or @deleted > @inserted
update s
  set 
    s.AllocQty = round(s.AllocQty - coalesce(d.AllocQty,0) + coalesce(i.AllocQty,0), DecPlQty),
    s.QtyAlloc = round(s.AllocQty - coalesce(d.AllocQty,0) + coalesce(i.AllocQty,0), DecPlQty),
    s.QtyShipNotInv = round(s.QtyShipNotInv - coalesce(d.QtyShipNotInv,0) + coalesce(i.QtyShipNotInv,0),DecPlQty),
    s.QtyAvail = round(s.QtyOnHand - QtyAllocBM - QtyAllocIN  - QtyAllocOther - QtyAllocPORet - QtyAllocSD - QtyAllocSO
                       + (Case When InclQtyOnPO = 1 Then s.QtyOnPo Else 0 End) 
                       + (Case When InclQtyInTransit = 1 Then s.QtyInTransit + s.QtyOnTransferOrders Else 0 End)                          
                       + (Case When InclQtyOnWO = 1 Then s.QtyOnKitAssyOrders Else 0 End)
                       - (Case When InclQtyCustOrd = 1 Then s.QtyCustOrd Else 0 End)
                       - (Case When InclQtyOnBO = 1 Then s.QtyOnBO Else 0 End)
                       - (Case When InclAllocQty = 1 Then s.AllocQty - coalesce(d.AllocQty,0) + coalesce(i.AllocQty,0) Else 0 End)
                       - s.QtyNotAvail 
                       - (s.QtyShipNotInv - coalesce(d.QtyShipNotInv,0) + coalesce(i.QtyShipNotInv,0)), DecPlQty)

from 
(select cpnyid, invtid, siteid, slstype from deleted union select cpnyid, invtid, siteid, slstype from inserted) v
inner loop join ItemSite s on s.CpnyId = v.CpnyId and s.InvtId = v.InvtId and s.SiteId = v.SiteId
left loop join (select det.CpnyId, det.InvtId, det.SiteId, 
           AllocQty = sum(case when unitmultdiv = 'M' then lineqty * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then lineqty / unitrate
                              else 0 end * st.InclQtyAlloc),
           QtyShipNotInv = sum(case when unitmultdiv = 'M' then lineqty * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then lineqty / unitrate
                              else 0 end * st.InclQtyShipNotInv)
           from deleted det
           inner loop join xsworderstatus st (nolock) on st.OrderType = @DespatchType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.SOType
           where slstype = 'GI' and det.SWFuture1 != '1' and y.INDocType not in ('NA','CM','RI')
           group by det.CpnyId, det.InvtId, det.SiteId) d on d.CpnyId = v.CpnyId and d.InvtId = v.InvtId and d.SiteId = v.SiteId
left loop join (select det.CpnyId, det.InvtId, det.SiteId, 
           AllocQty = sum(case when unitmultdiv = 'M' then lineqty * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then lineqty / unitrate
                              else 0 end * st.InclQtyAlloc), 
           QtyShipNotInv = sum(case when unitmultdiv = 'M' then lineqty * unitrate 
                              when unitmultdiv = 'D' and unitrate <> 0 then lineqty / unitrate
                              else 0 end * st.InclQtyShipNotInv)
           from inserted det
           inner loop join xswSlsOrdDsp do on do.CpnyId = det.CpnyId and do.DespatchNbr = det.DespatchNbr and do.OrderNbr = det.AltOrderNbr
           inner loop join xswOrderStatus st (nolock) on st.OrderType = @DespatchType and st.Status = do.SWFuture1
           inner loop join xswOrderType y (nolock) on y.OrderType = do.OrderType
           where slstype = 'GI' and det.SWFuture1 != '1' and y.INDocType not in ('NA','CM','RI')
           group by det.CpnyId, det.InvtId, det.SiteId) i on i.CpnyId = v.CpnyId and i.InvtId = v.InvtId and i.SiteId = v.SiteId 
cross join INSetup (nolock)
where v.SlsType = 'GI' 
AND (abs(coalesce(d.AllocQty,0) - coalesce(i.AllocQty,0)) > 0.0000001 or 
     abs(coalesce(d.QtyShipNotInv,0) - coalesce(i.QtyShipNotInv,0)) > 0.000000001)
OPTION (FORCE ORDER)
if @@error !=0 return

/**/
if update(altordernbr) or update(altlineref) or (update(status) /*and exists(select * from inserted where status = 'L')*/) or update (lineqty) or @deleted > @inserted
UPDATE s
set 
  s.AltQty = s.AltQty - coalesce(d.lineqty,0) + coalesce(i.lineqty,0),
  s.MUOMAltQty = 
coalesce(nullif(case when u.UOM3 = '' then '' else case when u.UOM3 = s.SlsUnit then convert(varchar,s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0)) else convert(varchar,floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0) / (case when u.MultDiv3 = 'M' then u.CnvFact3 else 1/u.CnvFact3 end)))) + '/' end end 
              + case when (u.UOM2 = '' or UOM3 = s.SlsUnit)  then '' else case when u.UOM2 = s.SlsUnit then convert(varchar,s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0) - (case when u.UOM3 = '' then 0 else (case when u.MultDiv3 = 'M' then u.CnvFact3 else 1/u.CnvFact3 end)* floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0)/(case when u.MultDiv3 = 'M' then u.CnvFact3 else 1/u.CnvFact3 end))) end)) else convert(varchar,floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0) - (case when u.UOM3 = '' then 0 else (case when u.MultDiv3 = 'M' then u.CnvFact3 else 1/u.CnvFact3 end)* floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0)/(case when u.MultDiv3 = 'M' then u.CnvFact3 else 1/u.CnvFact3 end))) end))/(case when u.MultDiv2 = 'M' then u.CnvFact2 else 1/u.CnvFact2 end))) + '/' end End 
              + case when (u.UOM1 = '' or UOM3 = s.SlsUnit or UOM2 = s.SlsUnit) then '' else case when u.UOM1 = s.SlsUnit then convert(varchar,s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0) - (case when u.UOM2 = '' then 0 else (case when u.MultDiv2 = 'M' then u.CnvFact2 else 1/u.CnvFact2 end)* floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0)/(case when u.MultDiv2 = 'M' then u.CnvFact2 else 1/u.CnvFact2 end))) end)) else convert(varchar,floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0) - (case when u.UOM2 = '' then 0 else (case when u.MultDiv2 = 'M' then u.CnvFact2 else 1/u.CnvFact2 end)* floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0)/(case when u.MultDiv2 = 'M' then u.CnvFact2 else 1/u.CnvFact2 end))) end))/(case when u.MultDiv1 = 'M' then u.CnvFact1 else 1/u.CnvFact1 end))) + '/' end End 
              + case when (u.UOM1 = u.UOM or UOM3 = s.SlsUnit or UOM2 = s.SlsUnit or UOM = s.SlsUnit) then '' else convert(varchar,floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0) - (case when u.UOM1 = '' then 0 else (case when u.MultDiv1 = 'M' then u.CnvFact1 else 1/u.CnvFact1 end)*floor((s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0)/(case when u.MultDiv1 = 'M' then u.CnvFact1 else 1/u.CnvFact1 end))) end))))END, ''), convert(varchar(10),s.AltQty-coalesce(d.lineqty,0)+coalesce(i.lineqty,0))) 
from 
(select CpnyId, AltOrderNbr, AltLineRef, SlsType from deleted union select CpnyId, AltOrderNbr, AltLineRef, SlsType from inserted) v
inner loop join xswSlsOrdDet s on s.CpnyID = v.CpnyID and s.OrderNbr = v.AltOrderNbr and s.LineRef = v.AltLineRef
inner join xswInvtConvUnit u (nolock) on u.InvtID = s.InvtID
left loop join (
  select det.CpnyId, det.AltOrderNbr, det.AltLineRef, LineQty = sum(det.LineQty), CuryLineAmt = sum(det.CuryLineAmt) 
  from deleted det
  where det.Status != 'L'
  group by det.CpnyId, det.AltOrderNbr, det.AltLineRef) d on d.CpnyId = v.CpnyId and d.AltOrderNbr = v.AltOrderNbr and d.AltLineRef = v.AltLineRef 
left loop join (
  select det.CpnyId, det.AltOrderNbr, det.AltLineRef, LineQty = sum(det.LineQty), CuryLineAmt = sum(det.CuryLineAmt) 
  from inserted det 
--  inner loop join xswDespatchOrd do on do.CpnyId = det.CpnyId and do.DespatchNbr = det.DespatchNbr 
  inner loop join xswSlsOrdDsp do on do.CpnyId = det.CpnyId and do.DespatchNbr = det.DespatchNbr and do.OrderNbr = det.AltOrderNbr
--  where do.Status != 'L'
  where do.SWFuture1 != 'L'
  group by det.CpnyId, det.AltOrderNbr, det.AltLineRef) i on i.CpnyId = v.CpnyId and i.AltOrderNbr = v.AltOrderNbr and i.AltLineRef = v.AltLineRef  
where v.SlsType = 'GI'
AND (abs(coalesce(d.lineqty,0) - coalesce(i.lineqty,0)) >  0.0000001 or 
     abs(coalesce(d.curylineamt,0) - coalesce(i.curylineamt,0)) >  0.0000001)
OPTION(FORCE ORDER)
if @@error !=0 return

/*this requires additional attention
UPDATE p 
set
  p.altqty = s.lineqty - s.altqty,
  p.curyaltamt = s.curylineamt - s.curyaltamt
from 
(select CpnyId, DespatchNbr, AltOrderNbr, AltLineRef, SlsType from deleted union select CpnyId, DespatchNbr, AltOrderNbr, AltLineRef, SlsType from inserted) v
inner loop join xswDspOrdDet p on p.cpnyid = v.cpnyid and p.altordernbr = v.altordernbr and p.altlineref = v.altlineref
inner loop join xswSlsOrdDet s on s.cpnyid = v.cpnyid and s.ordernbr = v.altordernbr and s.lineref = v.altlineref
where 
v.SlsType in ('GI','MI') and (p.UpdProg = '05010' and p.DespatchNbr != v.DespatchNbr or p.UpdProg != '05010')-- avoid another process ..
OPTION(FORCE ORDER)
if @@error !=0 return
*/


if update(SlsPerID) or update(BudgetIDC1) or update(DiscAmtC1) or update(Status) or @deleted > @inserted
update s set 
    s.QtyAmtSpent = round(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0), @BaseDecPl),
    s.QtyAmtAvail = round(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0), @BaseDecPl)
from 
(select SlsPerID, BudgetIDC1 from deleted union select SlsPerID, BudgetIDC1 from inserted) v
inner loop join xswDiscAlloc s on s.SlsPerID = v.SlsPerID and s.BudgetID = v.BudgetIDC1
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from deleted det
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = @DespatchType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.SOType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) d on d.SlsPerID = v.SlsPerID and d.BudgetIDC1 = v.BudgetIDC1
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from inserted det
           inner loop join xswSlsOrdDsp so on so.CpnyId = det.CpnyId and so.DespatchNbr = det.DespatchNbr and so.OrderNbr = det.AltOrderNbr 
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = @DespatchType and st.Status = so.SWFuture1
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) i on i.SlsPerID = v.SlsPerID and i.BudgetIDC1 = v.BudgetIDC1
where (abs(coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) >= 0.00005)
OPTION (FORCE ORDER) 
if @@error <> 0 return

if update(SlsPerID) or update(BudgetIDC2) or update(DiscAmtC2) or update(Status) or @deleted > @inserted
update s set 
    s.QtyAmtSpent = round(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0), @BaseDecPl),
    s.QtyAmtAvail = round(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0), @BaseDecPl)
from 
(select SlsPerID, BudgetIDC2 from deleted union select SlsPerID, BudgetIDC2 from inserted) v
inner loop join xswDiscAlloc s on s.SlsPerID = v.SlsPerID and s.BudgetID = v.BudgetIDC2
left loop join (select det.SlsPerID, det.BudgetIDC2, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from deleted det
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = @DespatchType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.SOType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC2) d on d.SlsPerID = v.SlsPerID and d.BudgetIDC2 = v.BudgetIDC2
left loop join (select det.SlsPerID, det.BudgetIDC2, 
           QtyAmtSpent = sum(det.DiscAmt * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from inserted det
           inner loop join xswSlsOrdDsp so on so.CpnyId = det.CpnyId and so.DespatchNbr = det.DespatchNbr and so.OrderNbr = det.AltOrderNbr 
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = @DespatchType and st.Status = so.SWFuture1
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 0 and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC2) i on i.SlsPerID = v.SlsPerID and i.BudgetIDC2 = v.BudgetIDC2
where (abs(coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) >= 0.00005)
OPTION (FORCE ORDER) 
if @@error <> 0 return


/*Manual FreeItems*/
if update(SlsPerID) or update(BudgetIDC1) or update(LineQty) or update(FreeItem) or update(Status) or @deleted > @inserted
update s set 
    s.QtyAmtSpent = round(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0), @DecPlQty),
    s.QtyAmtAvail = round(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0), @DecPlQty),
	s.MUOMQtySpent = 
		coalesce(nullif(left(sign(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)),1),'1'),'')+
		coalesce(convert(varchar, floor(abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) * NCnvFact3)) + '/','') + 
		coalesce(convert(varchar, floor((abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * NCnvFact2)) + '/', '') +
		convert(varchar, abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) - CnvFact2 * floor((abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtSpent - coalesce(d.QtyAmtSpent,0) + coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * RCnvFact2)),
	s.MUOMQtyAvail = 
		coalesce(nullif(left(sign(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)),1),'1'),'')+
		coalesce(convert(varchar, floor(abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) * NCnvFact3)) + '/','') + 
		coalesce(convert(varchar, floor((abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * NCnvFact2)) + '/', '') +
		convert(varchar, abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) - CnvFact2 * floor((abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) - CnvFact3 * floor(abs(s.QtyAmtAlloc - s.QtyAmtSpent + coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) * RCnvFact3)) * RCnvFact2)) 
from 
(select SlsPerID, BudgetIDC1 from deleted union select SlsPerID, BudgetIDC1 from inserted) v
inner loop join xswDiscAlloc s on s.SlsPerID = v.SlsPerID and s.BudgetID = v.BudgetIDC1
inner join xsw_vpInvtConvUnit u2 (nolock) on u2.InvtID = s.FreeItemID
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(case when det.UnitMultDiv = 'M' then det.LineQty * det.UnitRate when det.UnitRate <> 0 then det.LineQty / det.UnitRate else 0 end * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from deleted det
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = @DespatchType and st.Status = det.Status 
           inner loop join xswOrderType y (nolock) on y.OrderType = det.SOType
           where det.SlsType = 'GI' and det.FreeItem = 1 and det.LineRef like '[0-9]%' and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) d on d.SlsPerID = v.SlsPerID and d.BudgetIDC1 = v.BudgetIDC1
left loop join (select det.SlsPerID, det.BudgetIDC1, 
           QtyAmtSpent = sum(case when det.UnitMultDiv = 'M' then det.LineQty * det.UnitRate when det.UnitRate <> 0 then det.LineQty / det.UnitRate else 0 end * st.InclBudgetSpent * case when y.ARDocType = 'CM' then -1 else 1 end)
           from inserted det
           inner loop join xswSlsOrdDsp so on so.CpnyId = det.CpnyId and so.DespatchNbr = det.DespatchNbr and so.OrderNbr = det.AltOrderNbr 
           inner loop join xsw_vpBudgetStatus st (nolock) on st.OrderType = @DespatchType and st.Status = so.SWFuture1
           inner loop join xswOrderType y (nolock) on y.OrderType = so.OrderType
           where det.SlsType = 'GI' and det.FreeItem = 1 and det.LineRef like '[0-9]%' and y.ARDocType <> 'NA'
           group by det.SlsPerID, det.BudgetIDC1) i on i.SlsPerID = v.SlsPerID and i.BudgetIDC1 = v.BudgetIDC1
where (abs(coalesce(d.QtyAmtSpent,0) - coalesce(i.QtyAmtSpent,0)) >= 0.00005)
OPTION (FORCE ORDER)

go

