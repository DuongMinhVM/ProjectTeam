
Create Trigger tr_Update_Vendor
On
Vendor
For UPDATE,INSERT
AS
If (Update(Name) OR Update(Status) OR Update(terms) OR Update(ClassID) OR Update(Addr1) OR Update(Addr2))
Begin
	Update Vendor set User1 = 0
	Where VendID in (Select VendID from Inserted)
End
go

