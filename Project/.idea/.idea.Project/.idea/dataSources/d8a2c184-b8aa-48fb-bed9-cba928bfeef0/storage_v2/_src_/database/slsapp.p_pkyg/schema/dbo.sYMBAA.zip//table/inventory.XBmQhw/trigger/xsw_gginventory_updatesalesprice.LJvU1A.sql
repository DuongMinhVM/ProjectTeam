
CREATE TRIGGER xsw_ggInventory_UpdateSalesPrice ON Inventory FOR INSERT, UPDATE, DELETE AS

SET NOCOUNT ON

IF (UPDATE(StkBasePrc) OR UPDATE(User6))
BEGIN
DELETE p
FROM deleted d
INNER JOIN inserted i ON i.InvtID = d.InvtID AND i.User6 != d.User6
CROSS JOIN GLSetup (NOLOCK)
INNER JOIN xswSalesPrice p ON
p.CuryID = BaseCuryID and p.InvtID = d.InvtID and p.UOM = d.User6
IF @@ERROR != 0 RETURN

UPDATE p SET
  p.SlsPrice = CASE WHEN p.SlsPrice < 0.0005 THEN i.StkBasePrc ELSE p.SlsPrice END,
  p.RvsdPrice = CASE WHEN p.SlsPrice >= 0.0005 AND p.RvsdPrice < 0.0005 THEN i.StkBasePrc ELSE p.RvsdPrice END,
  p.EffDate = CASE WHEN p.SlsPrice >= 0.0005 AND p.RvsdPrice < 0.0005 
			THEN convert(smalldatetime, convert(char(8), getdate(), 112), 112) 
			ELSE p.EffDate
			END,
  p.UpdProg = i.LUpd_Prog,
  p.UpdUser = i.LUpd_User,
  p.UpdDateTime = getdate()
FROM inserted i
CROSS JOIN GLSetup (NOLOCK)
INNER JOIN xswSalesPrice p ON
p.CuryID = BaseCuryID and p.InvtID = i.InvtID and p.UOM = i.User6
WHERE i.LUpd_Prog not in ('OP540','10250')
IF @@ERROR != 0 RETURN

INSERT xswSalesPrice (
CuryID, EffDate, InvtID, LastDate, LastPrice, RvsdPrice, SlsPrice, UOM,
NoteID,
SWFuture1, SWFuture2, SWFuture3, SWFuture4, SWFuture5, SWFuture6,
CrtdProg, CrtdUser, CrtdDateTime, UpdProg, UpdUser, UpdDateTime,
User1, User2, User3, User4, User5, User6, User7, User8,
/*60*/TaxID, TaxRate, RvsdTaxID, RvsdTaxRate, LastTaxID, LastTaxRate)
SELECT
BaseCuryID, '', InvtID, '01/01/1900', 0, 0, StkBasePrc, i.User6, 0,
'', '', '', '', '', '',
i.LUpd_Prog, i.LUpd_User, getdate(), i.LUpd_Prog, i.LUpd_User, getdate(),
'', '', 0, 0, '', '', '', '',
/*60*/'', 0, '', 0, '', 0
FROM inserted i
CROSS JOIN GLSetup (NOLOCK)
WHERE NOT EXISTS (SELECT * FROM xswSalesPrice p WHERE p.CuryID = BaseCuryID
and p.InvtID = i.InvtID and p.UOM = i.User6)
IF @@ERROR != 0 RETURN
END

-- Update standard cost, pending cost and Purchasing price with new sales price
IF (UPDATE(StkBasePrc) AND (SELECT User6 FROM POSetup) = 'Y') 
BEGIN

	DECLARE @prcpl FLOAT
	SELECT @prcpl = DecPlPrcCst FROM INSetup

	UPDATE g SET
		ListPrice = round(
			(i.StkBasePrc * c2.CnvFact/c1.CnvFact)
			* (1 - p.MinGrossProfit/100)
			* CASE rtrim(s.User2) WHEN 'Y' THEN isnull(1 - v.User3/100, 1) ELSE 1 END
			, @prcpl)
	FROM InventoryADG g
	INNER JOIN inserted i ON g.InvtID = i.InvtID AND i.ValMthd = 'T' AND i.LUpd_Prog != '10250'
	INNER JOIN INUnit c1 ON i.InvtID = c1.InvtID AND c1.ToUnit = i.StkUnit AND c1.FromUnit = i.User6
	INNER JOIN INUnit c2 ON i.InvtID = c2.InvtID AND c2.ToUnit = i.StkUnit AND c2.FromUnit = i.DfltPOUnit
	INNER JOIN ProductClass p ON p.ClassID = i.ClassID
	LEFT JOIN Vendor v ON v.VendID = p.User1
	CROSS JOIN POSetup s

	UPDATE i SET
		i.PStdCostDate = convert(smalldatetime, convert(char(8), getdate(), 112), 112),
-- calculate cost from po price
		i.PDirStdCost = round(
			CASE rtrim(ps.User2) WHEN 'Y' THEN g.ListPrice ELSE g.ListPrice *
			isnull(1 - v.User3/100, 1) END / isnull(1 + t.TaxRate/100, 1) /
			CASE i.DfltPOUnit
				WHEN u.UOM1 THEN u.CnvFact1
				WHEN u.UOM2 THEN u.CnvFact2
				WHEN u.UOM3 THEN u.CnvFact3
				ELSE 1 END, @prcpl),
		i.PStdCost = round(
			CASE rtrim(ps.User2) WHEN 'Y' THEN g.ListPrice ELSE g.ListPrice *
			isnull(1 - v.User3/100, 1) END / isnull(1 + t.TaxRate/100, 1) /
			CASE i.DfltPOUnit
				WHEN u.UOM1 THEN u.CnvFact1
				WHEN u.UOM2 THEN u.CnvFact2
				WHEN u.UOM3 THEN u.CnvFact3
				ELSE 1 END, @prcpl)
-- calculate cost directly from so price
-- i.PDirStdCost = round(
-- i.StkBasePrc * (1 - p.MinGrossProfit/100) * isnull(1 - v.User3/100, 1) /isnull(1 + t.TaxRate/100, 1) /
-- CASE i.User6
-- WHEN u.UOM1 THEN u.CnvFact1
-- WHEN u.UOM2 THEN u.CnvFact2
-- WHEN u.UOM3 THEN u.CnvFact3
-- ELSE 1 END, @prcpl),
-- i.PStdCost = round(
-- i.StkBasePrc * (1 - p.MinGrossProfit/100) * isnull(1 - v.User3/100, 1) /isnull(1 + t.TaxRate/100, 1) /
-- CASE i.User6
-- WHEN u.UOM1 THEN u.CnvFact1
-- WHEN u.UOM2 THEN u.CnvFact2
-- WHEN u.UOM3 THEN u.CnvFact3
-- ELSE 1 END, @prcpl)
	FROM inserted s
	INNER JOIN Inventory i ON i.InvtID = s.InvtID
	INNER JOIN InventoryADG g ON g.InvtID = s.InvtID
	INNER JOIN ProductClass p ON p.ClassID = s.ClassID
	INNER JOIN xswInvtConvUnit u ON u.InvtID = s.InvtID
	LEFT JOIN Vendor v ON v.VendID = p.User1
	LEFT JOIN SalesTax t ON 
		t.TaxId = v.TaxId00 AND t.PrcTaxIncl = 'Y' AND (
		(t.CatFlg = 'A' AND t.CatExcept00 <> s.TaxCat) OR
		(t.CatFlg = 'N' AND t.CatExcept00 = s.TaxCat))
	CROSS JOIN POSetup ps
	WHERE s.ValMthd = 'T' AND s.LUpd_Prog != '10250'
END
go

