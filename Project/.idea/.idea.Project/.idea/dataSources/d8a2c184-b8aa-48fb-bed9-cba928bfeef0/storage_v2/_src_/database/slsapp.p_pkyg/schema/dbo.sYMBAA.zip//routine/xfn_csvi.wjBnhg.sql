
create function xfn_CsvI (@i int) RETURNS varchar(13) AS
BEGIN 
        RETURN '"' + isnull(ltrim(str(@i, 11, 0)), '') + '"' 
END
go

