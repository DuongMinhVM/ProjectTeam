
create trigger [gg_xswInvtConvUnit01] ON [dbo].[xswInvtConvUnit] 
FOR INSERT, UPDATE, DELETE 
AS 

Delete from l from inunit l inner join
(select k.invtID, k.toUnit, k.fromUnit from inunit k inner join inserted d on 
k.InvtID = d.InvtID and ((k.toUnit <> UOM) or (k.Fromunit <> UOM1 and k.Fromunit <> UOM2 and k.Fromunit <> UOM3))) s
on s.InvtID = l.InvtID and s.toUnit = l.tounit and s.fromunit = l.fromunit

Delete from l from inunit l inner join
(select k.invtID, k.toUnit, k.fromUnit from inunit k inner join deleted d on 
k.InvtID = d.InvtID left join inserted r on d.invtID = r.InvtID where r.InvtID is Null ) s
on s.InvtID = l.InvtID and s.toUnit = l.tounit and s.fromunit = l.fromunit

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*', 1,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM','M',0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM = ToUnit and i.UOM = t.FromUnit
where t.InvtID is null and i.UOM <> ''

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*', i.CnvFact1,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM1,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM',i.MultDiv1,0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM = ToUnit and i.UOM1 = t.FromUnit
where t.InvtID is null and i.UOM1 <> ''

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*',1,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM1,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM','M',0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM1,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM1 = ToUnit and i.UOM1 = t.FromUnit
where t.InvtID is null and i.UOM1 <> ''

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*', i.CnvFact2,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM2,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM','M',0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM = ToUnit and i.UOM2 = t.FromUnit
where t.InvtID is null and i.UOM2 <> ''

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*', 1,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM2,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM','M',0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM2,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM2 = ToUnit and i.UOM2 = t.FromUnit
where t.InvtID is null and i.UOM2 <> ''

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*', i.CnvFact3,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM3,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM',i.MultDiv3,0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM = ToUnit and i.UOM3 = t.FromUnit
where t.InvtID is null and i.UOM3 <> ''

insert inunit
(ClassID,CnvFact,Crtd_DateTime,Crtd_Prog,Crtd_User,FromUnit,
InvtId,LUpd_DateTime,LUpd_Prog,LUpd_User,MultDiv,NoteID,
S4Future01,S4Future02,S4Future03,S4Future04,S4Future05,
S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,ToUnit,UnitType,User1,User2,User3,
User4,User5,User6,User7,User8)
select 
'*', 1,convert(smalldatetime,getdate()), '10250', 'SYSTEM', i.UOM3,
i.InvtID,convert(smalldatetime,getdate()),'10250', 'SYSTEM','M',0,
'','',0,0,0,0,'01/01/1900','01/01/1900',0,0,'','',i.UOM3,3,
'','',0,0,'','','01/01/1900','01/01/1900'
from inserted i left join inunit t on i.INvtID = t.InvtID and i.UOM3 = ToUnit and i.UOM3 = t.FromUnit
where t.InvtID is null and i.UOM3 <> ''

update inunit set 
CnvFact = i.CnvFact1,
LUpd_DateTime = convert(smalldatetime,getdate()),
MultDiv = i.MultDiv1
from inserted i inner join deleted d on i.INvtID = d.INvtID
inner join inunit t on i.INvtID = t.InvtID and i.UOM1 = t.FromUnit and i.UOM = t.ToUnit 
and (t.CnvFact <> i.CnvFact1 or t.MultDiv <> i.MultDiv1)

update inunit set 
CnvFact = i.CnvFact2,
LUpd_DateTime = convert(smalldatetime,getdate()),
MultDiv = i.MultDiv2
from inserted i inner join deleted d on i.INvtID = d.INvtID
inner join inunit t on i.INvtID = t.InvtID and i.UOM2 = t.FromUnit and i.UOM = t.ToUnit
and (t.CnvFact <> i.CnvFact2 or t.MultDiv <> i.MultDiv2)

update inunit set 
CnvFact = i.CnvFact3,
LUpd_DateTime = convert(smalldatetime,getdate()),
MultDiv = i.MultDiv3
from inserted i inner join deleted d on i.INvtID = d.INvtID
inner join inunit t on i.INvtID = t.InvtID and i.UOM3 = t.FromUnit and i.UOM = t.ToUnit
and (t.CnvFact <> i.CnvFact3 or t.MultDiv <> i.MultDiv3)
go

