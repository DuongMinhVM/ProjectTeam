
CREATE  TRIGGER xsw_ggBatch_TransferQtyUpdate ON [dbo].[Batch] 
FOR UPDATE
AS

if update(status)
if exists(select * from inserted where Module = 'IN' and EditScrnNbr = '10040' and Status in ('C','U')) 
BEGIN
   Update S set S.QtyShipNotInv = Round(s.QtyShipNotInv -  v.Qty, P.DecPlQty)
   from
   (select t.InvtID, t.SiteID, Qty = coalesce(sum(t.Qty * case when t.UnitMultDiv = 'D' then 1/t.CnvFact else t.CnvFact end),0) from inserted i inner join deleted d
              on i.MOdule = 'IN' and i.EditScrnNbr = '10040' and i.JrnlType = 'OM' and i.Crtd_Prog = '400.I' and i.Batnbr = d.Batnbr and  i.module = d.module and I.status <> d.Status and I.Status in ('C','U')
              Inner join INtran t on d.Batnbr = t.Batnbr and rtrim(t.ToWhseLoc) <> ''
              Group by t.INvtID , t.SiteID
    ) v
    Inner join ItemSite S on v.SiteID = s.SiteID and v.INvtID = s.InvtID
    cross join INSetup P
    Where v.Qty > 0
    OPTION (FORCE ORDER)

   Update S set S.QtyShipNotInv = Round(s.QtyShipNotInv -  v.Qty, P.DecPlQty)
   From 
   (select t.InvtID, t.SiteID, t.WhseLoc, Qty = sum(t.Qty * case when t.UnitMultDiv = 'D' then 1/t.CnvFact else t.CnvFact end) from inserted i inner join deleted d
              on i.MOdule = 'IN' and i.EditScrnNbr = '10040' and i.JrnlType = 'OM' and i.Crtd_Prog = '400.I' and i.Batnbr = d.Batnbr and  i.module = d.module and I.status <> d.Status and I.Status in ('C','U')
              Inner join INtran t on d.Batnbr = t.Batnbr and rtrim(t.ToWhseLoc) <> ''
              Group by t.INvtID , t.SiteID, t.WhseLoc
    ) v
    Inner join Location S on v.SiteID = s.SiteID and v.INvtID = s.InvtID and v.WhseLoc = S.WhseLoc
    cross join INSetup P
    Where v.Qty > 0
    OPTION (FORCE ORDER)
             
    
    Update S set s.QtyNotAvail = qty from      
              (Select l.INvtID, l.SiteID, qty = sum(QtyOnHand) from
             (select distinct t.InvtID, t.SiteID from inserted i inner join deleted d
              on i.MOdule = 'IN' and i.EditScrnNbr = '10040' and i.Batnbr = d.Batnbr and  i.module = d.module and I.status <> d.Status and I.Status in ('C','U')
              Inner join INtran t on d.Batnbr = t.Batnbr and rtrim(t.ToWhseLoc) <> ''
              Group by t.INvtID , t.SiteID) v inner join location L on L.SiteID = v.SiteID and L.InvtID = v.INvtID 
              inner join loctable t on t.SiteID = l.SiteID and t.Whseloc = l.whseloc and t.inclqtyavail = 0
              group by l.INvtID, l.SiteID) v1
              Inner join ItemSite S on v1.SiteID = s.SiteID and v1.INvtID = s.InvtID
              OPTION (FORCE ORDER)
    
    Update S set
               s.QtyAvail = round(s.QtyOnHand - QtyAllocBM - QtyAllocIN  - QtyAllocOther - QtyAllocPORet - QtyAllocSD - QtyAllocSO
                       + (Case When P.InclQtyOnPO = 1 Then s.QtyOnPo Else 0 End) 
                       + (Case When P.InclQtyInTransit = 1 Then ROUND(s.QtyInTransit + s.QtyOnTransferOrders, P.DecPlQty)  Else 0 End)                          
                       + (Case When P.InclQtyOnWO = 1 Then s.QtyOnKitAssyOrders Else 0 End)
                       - (Case When P.InclQtyCustOrd = 1 Then s.QtyCustOrd Else 0 End)
                       - (Case When P.InclQtyOnBO = 1 Then s.QtyOnBO  Else 0 End)
                       - (Case When P.InclAllocQty = 1 Then s.AllocQty  Else 0 End)
                       - s.QtyNotAvail 
                         - ROUND(s.QtyShipNotInv, P.DecPlQty), P.DecPlQty)
    from
    (select distinct t.InvtID, t.SiteID from inserted i inner join deleted d
              on i.Module = 'IN' and i.EditScrnNbr = '10040' and i.Batnbr = d.Batnbr and  i.module = d.module and I.status <> d.Status and I.Status in ('C','U')
              Inner join INtran t on d.Batnbr = t.Batnbr and rtrim(t.ToWhseLoc) <> ''
              Group by t.INvtID , t.SiteID
    ) v
    Inner join ItemSite S on v.SiteID = s.SiteID and v.INvtID = s.InvtID
    cross join INSetup P
    OPTION (FORCE ORDER)
end

go

