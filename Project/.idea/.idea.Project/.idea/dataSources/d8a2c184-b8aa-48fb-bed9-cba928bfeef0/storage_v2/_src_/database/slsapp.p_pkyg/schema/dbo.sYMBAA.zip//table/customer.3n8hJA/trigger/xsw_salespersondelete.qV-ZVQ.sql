
create trigger xsw_SalespersonDelete ON Customer 
FOR DELETE as

Delete from s from salesperson s inner join deleted d on d.custID = s.SlsperId 
Delete from s from Slsperhist S inner join deleted d on d.custID = s.SlsperId 
Delete from s from xswPJPcustomer s inner join deleted d on d.custID = s.custID
delete from s from Soaddress s inner join deleted d on d.custID = s.custID
go

