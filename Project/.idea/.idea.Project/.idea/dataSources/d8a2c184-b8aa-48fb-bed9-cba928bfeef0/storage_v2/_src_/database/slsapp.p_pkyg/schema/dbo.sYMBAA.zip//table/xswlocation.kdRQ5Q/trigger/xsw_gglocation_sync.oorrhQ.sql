
CREATE   trigger xsw_ggLocation_Sync ON [xswLocation] 
for UPDATE, DELETE as

set nocount on

if exists(select top 1 WhseLoc from inserted) and not exists(select top 1 WhseLoc from deleted)
BEGIN
	/*INSERT missing LocTable*/
	insert LocTable(ABCCode, AssemblyValid, BinType, CountStatus, Crtd_DateTime, Crtd_Prog, Crtd_User, CycleID, Descr, InclQtyAvail, InvtID, 
	InvtIDValid, LastBookQty, LastCountDate, LastVarAmt, LastVarPct, LastVarQty, LUpd_DateTime, LUpd_Prog, LUpd_User, MoveClass, NoteID, 
	PickPriority, PutAwayPriority, ReceiptsValid, S4Future01, S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, 
	S4Future08, S4Future09, S4Future10, S4Future11, S4Future12, SalesValid, Selected, SiteID, User1, User2, User3, User4, User5, User6, User7, 
	User8, WOIssueValid, WOProdValid, WhseLoc)
	select '', 'Y', 'N', 'A', getdate(), i.CrtdProg, i.CrtdUser, '', '', 1, '', 
	'N', 0, '', 0, 0, 0, getdate(), i.CrtdProg, i.CrtdUser, '', 0, 
	0, 0, 'Y', '', '', 0, 0, 0, 0, '', 
	'', 0, 0, '', '', 'Y', 1, i.SiteID, '', '', 0, 0, '', '', '', 
	'', '', '', i.WhseLoc
	from 
	(select SiteID, WhseLoc, CrtdProg = max(user5), CrtdUser = max(user6) 
	from inserted 
	where WhseLoc != ''
	group by SiteID, WhseLoc) i
	left loop join LocTable l on l.SiteId = i.SiteId and l.WhseLoc = i.WhseLoc
	where l.InvtId is null OPTION (FORCE ORDER) 
	if @@error !=0 return

	/*INSERT missing Location*/
	insert Location(CountStatus, Crtd_DateTime, Crtd_Prog, Crtd_User, InvtID, LUpd_DateTime, LUpd_Prog, LUpd_User, NoteID, QtyAlloc, QtyOnHand, 
	QtyShipNotInv, QtyWORlsedDemand, S4Future01, S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09, 
	S4Future10, S4Future11, S4Future12, Selected, SiteID, User1, User2, User3, User4, User5, User6, User7, User8, WhseLoc,
	/*60*/QtyAllocBM, QtyAllocIN, QtyAllocOther, QtyAllocPORet, QtyAllocSD, QtyAllocSO, QtyAvail)
	select '', getdate(), i.User5, i.User6, i.InvtId, getdate(), i.User5, i.User6, 0, 0, 0, 
	0, 0, '', '', 0, 0, 0, 0, '', '', 0, 
	0, '', '', 0, i.SiteId, '', '', 0, 0, '', '', '', '', i.WhseLoc,
	/*60*/0, 0, 0, 0, 0, 0, 0
	from 
	inserted i
	left loop join Location l on l.InvtId = i.InvtId and l.SiteId = i.SiteId and l.WhseLoc = i.WhseLoc
	where i.WhseLoc != '' and l.InvtId is null OPTION (FORCE ORDER) 
	if @@error !=0 return
END

/*UPDATE Location*/
update l
  set 
    l.QtyAlloc = round(l.QtyAlloc - coalesce(d.QtyAlloc,0) + coalesce(i.QtyAlloc,0), DecPlQty),
    l.QtyShipNotInv = round(l.QtyShipNotInv - coalesce(d.QtyShipNotInv,0) + coalesce(i.QtyShipNotInv,0), DecPlQty),
    l.QtyAvail = round(l.QtyOnHand - QtyAllocBM - QtyAllocIN - QtyAllocOther - QtyAllocPORet - QtyAllocSD - QtyAllocSO 
                       - (Case When InclAllocQty = 1 Then l.QtyAlloc - coalesce(d.QtyAlloc,0) + coalesce(i.QtyAlloc,0) Else 0 End)
                       - l.QtyShipNotInv, DecPlQty)
from 
(select invtid, siteid, whseloc from deleted union select invtid, siteid, whseloc from inserted) v
inner join Location l on l.InvtId = v.InvtId and l.SiteID = v.SiteID and l.WhseLoc = v.WhseLoc
left join deleted d on d.InvtId = l.InvtId and d.SiteId = l.SiteId and d.WhseLoc = l.WhseLoc
left join inserted i on i.InvtId = l.InvtId and i.SiteId = l.SiteId and i.WhseLoc = l.WhseLoc 
cross join INSetup (nolock) 
where (abs(coalesce(d.QtyAlloc,0) - coalesce(i.QtyAlloc,0)) > 0.0000001 or
       abs(coalesce(d.QtyShipNotInv,0) - coalesce(i.QtyShipNotInv,0)) > 0.0000001)
if @@error !=0 return


go

