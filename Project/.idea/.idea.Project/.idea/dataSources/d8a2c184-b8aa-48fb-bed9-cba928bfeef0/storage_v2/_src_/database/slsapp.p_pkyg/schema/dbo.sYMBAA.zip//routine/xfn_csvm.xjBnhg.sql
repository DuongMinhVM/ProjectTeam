
create function xfn_CsvM (@invtid varchar(30), @q float) RETURNS varchar(17) AS
BEGIN 
        RETURN '"' + case when @q is null then '' else isnull('''' + dbo.fnMUOMizFloat(@invtid, round(@q, 0), '') + '''', ltrim(str(@q, 15))) end + '"' 
END
go

