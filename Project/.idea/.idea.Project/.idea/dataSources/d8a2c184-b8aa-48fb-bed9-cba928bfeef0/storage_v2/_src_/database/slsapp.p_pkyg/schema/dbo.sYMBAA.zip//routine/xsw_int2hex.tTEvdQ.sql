
create function xsw_int2hex(@x bigint, @n smallint = 8) RETURNS varchar(16)
AS
BEGIN
        DECLARE @r int
        DECLARE @i smallint
        DECLARE @s varchar(16)
        
        set @s = ''
        set @i = 0
        while @i < @n begin
                set @r = @x % 16
                set @x = @x / 16
                
                set @s = case
                        when @r < 10 then str(@r, 1)
                        when @r = 10 then 'a'
                        when @r = 11 then 'b'
                        when @r = 12 then 'c'
                        when @r = 13 then 'd'
                        when @r = 14 then 'e'
                        when @r = 15 then 'f'
                end + @s
        
                set @i = @i + 1
        end
        
        RETURN @s
END
go

