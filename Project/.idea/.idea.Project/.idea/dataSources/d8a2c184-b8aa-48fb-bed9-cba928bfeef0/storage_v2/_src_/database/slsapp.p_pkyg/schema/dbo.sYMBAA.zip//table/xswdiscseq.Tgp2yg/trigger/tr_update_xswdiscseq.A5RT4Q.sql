
Create Trigger tr_Update_xswDiscSeq
On
xswDiscSeq
For UPDATE,INSERT
AS
If (Update(Active) OR Update(BudgetID) OR Update(Descr) OR Update(FreeItemBudgetID) OR Update(FreeItemID))
Begin
	Declare @DiscID as varchar(10)
	Declare @DiscSeq as varchar (10)
	Select @DiscID =  DiscID, @DiscSeq = DiscSeq from Inserted
	Update xswDiscSeq set user4 =0
	Where DiscID = @DiscID and DiscSeq = @DiscSeq	
End

go

