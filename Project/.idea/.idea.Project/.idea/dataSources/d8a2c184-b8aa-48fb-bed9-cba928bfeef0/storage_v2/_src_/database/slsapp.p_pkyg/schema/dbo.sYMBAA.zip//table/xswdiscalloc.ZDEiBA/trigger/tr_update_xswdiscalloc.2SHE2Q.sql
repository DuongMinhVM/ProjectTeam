
Create trigger tr_Update_xswDiscAlloc
On
xswDiscAlloc
For UPDATE,INSERT
AS
If Update(QtyAmtAlloc) OR Update(QtyAmtAvail) OR Update(QtyAmtSpent) OR Update(SlsperID)
Begin
	Declare @BudgetID varchar(10)
	Declare @SlsPerID varchar(10)
	Select @BudgetID = Rtrim(BudgetID),@SlsPerID = SlsPerID From Inserted

	Update xswDiscAlloc set User4 =0
	Where BudgetID = @BudgetID  and SlsPerID =@SlsPerID
End
go

