
create function xsw_sysdb_name ()
	returns varchar(30)
begin 
-- returns database name of Solomon system DB
declare @text as varchar(8000)
declare @i as int

--sql2005 uses nvarchar
select top 1 @text = convert(varchar(8000), replace(ctext,0x00,'')) from syscomments
where id = object_id('vs_domain') and number = 0
order by colid

set @i = patindex('% FROM %', @text)
if @i <= 0 return null
set @text = substring(@text, @i + 6, 8000)

set @i = patindex('%.%', @text)
if @i <= 0 return null
set @text = ltrim(rtrim(left(@text, @i - 1)))

set @text = ltrim(rtrim(@text))
if len(@text) > 30 return null	-- too long than expected for Solomon DB

return convert(varchar(30), nullif(@text, ''))

END
go

