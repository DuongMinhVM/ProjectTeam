create function dbo.xsw_fnMasterLogin() RETURNS sysname
AS
	BEGIN
	RETURN ('MasterSW')
	END

go

