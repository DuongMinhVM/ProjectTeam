
create function xfn_CsvD (@d smalldatetime) RETURNS varchar(10) AS
BEGIN 
        RETURN '"' + isnull(convert(varchar(8), @d, 112), '') + '"' 
END
go

