
create trigger xsw_gg04010_SBBSTerms ON dbo.APDoc
for insert, update as

if not exists(select * from APDoc where docclass = 'N' and rlsed=0 and LUpd_Prog='04010')
return

update d set
  d.discdate = case
  when m.TermsID is null then d.InvcDate 
  when (datepart(day,d.InvcDate) between xm.DayFrom00 and xm.DayTo00 or xm.DayFrom01 <= xm.DayTo01 and datepart(day,d.InvcDate) not between xm.DayFrom01 and xm.DayTo01) and xm.DayDue00 > datepart(day,d.InvcDate) then dateadd(day, xm.DayDue00-datepart(day, d.InvcDate),d.InvcDate)
  when (datepart(day,d.InvcDate) between xm.DayFrom00 and xm.DayTo00 or xm.DayFrom01 <= xm.DayTo01 and datepart(day,d.InvcDate) not between xm.DayFrom01 and xm.DayTo01) and xm.DayDue00 <= datepart(day,d.InvcDate) then dateadd(day, xm.DayDue00-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate))
  when (datepart(day,d.InvcDate) between xm.DayFrom01 and xm.DayTo01 or xm.DayFrom00 <= xm.DayTo00 and datepart(day,d.InvcDate) not between xm.DayFrom00 and xm.DayTo00) and xm.DayDue01 > datepart(day,d.InvcDate) then dateadd(day, xm.DayDue01-datepart(day, d.InvcDate),d.InvcDate)
  when (datepart(day,d.InvcDate) between xm.DayFrom01 and xm.DayTo01 or xm.DayFrom00 <= xm.DayTo00 and datepart(day,d.InvcDate) not between xm.DayFrom00 and xm.DayTo00) and xm.DayDue01 <= datepart(day,d.InvcDate) then dateadd(day, xm.DayDue01-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate))
  when m.DiscType='D' THEN dateadd(day,m.DiscIntrv,d.InvcDate) 
  else dateadd(day, m.DiscIntrv-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate)) end,
  d.duedate = case
  when m.TermsID is null then d.InvcDate 
  when (datepart(day,d.InvcDate) between xm.DayFrom00 and xm.DayTo00 or xm.DayFrom01 <= xm.DayTo01 and datepart(day,d.InvcDate) not between xm.DayFrom01 and xm.DayTo01) and xm.DayDue00 > datepart(day,d.InvcDate) then dateadd(day, xm.DayDue00-datepart(day, d.InvcDate),d.InvcDate)
  when (datepart(day,d.InvcDate) between xm.DayFrom00 and xm.DayTo00 or xm.DayFrom01 <= xm.DayTo01 and datepart(day,d.InvcDate) not between xm.DayFrom01 and xm.DayTo01) and xm.DayDue00 <= datepart(day,d.InvcDate) then dateadd(day, xm.DayDue00-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate))
  when (datepart(day,d.InvcDate) between xm.DayFrom01 and xm.DayTo01 or xm.DayFrom00 <= xm.DayTo00 and datepart(day,d.InvcDate) not between xm.DayFrom00 and xm.DayTo00) and xm.DayDue01 > datepart(day,d.InvcDate) then dateadd(day, xm.DayDue01-datepart(day, d.InvcDate),d.InvcDate)
  when (datepart(day,d.InvcDate) between xm.DayFrom01 and xm.DayTo01 or xm.DayFrom00 <= xm.DayTo00 and datepart(day,d.InvcDate) not between xm.DayFrom00 and xm.DayTo00) and xm.DayDue01 <= datepart(day,d.InvcDate) then dateadd(day, xm.DayDue01-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate))
  when m.DueType='D' THEN dateadd(day,m.DueIntrv,d.InvcDate) 
  else dateadd(day, m.DueIntrv-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate)) end,
  d.paydate = case
  when m.TermsID is null then d.InvcDate 
  when (datepart(day,d.InvcDate) between xm.DayFrom00 and xm.DayTo00 or xm.DayFrom01 <= xm.DayTo01 and datepart(day,d.InvcDate) not between xm.DayFrom01 and xm.DayTo01) and xm.DayDue00 > datepart(day,d.InvcDate) then dateadd(day, xm.DayDue00-datepart(day, d.InvcDate),d.InvcDate)
  when (datepart(day,d.InvcDate) between xm.DayFrom00 and xm.DayTo00 or xm.DayFrom01 <= xm.DayTo01 and datepart(day,d.InvcDate) not between xm.DayFrom01 and xm.DayTo01) and xm.DayDue00 <= datepart(day,d.InvcDate) then dateadd(day, xm.DayDue00-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate))
  when (datepart(day,d.InvcDate) between xm.DayFrom01 and xm.DayTo01 or xm.DayFrom00 <= xm.DayTo00 and datepart(day,d.InvcDate) not between xm.DayFrom00 and xm.DayTo00) and xm.DayDue01 > datepart(day,d.InvcDate) then dateadd(day, xm.DayDue01-datepart(day, d.InvcDate),d.InvcDate)
  when (datepart(day,d.InvcDate) between xm.DayFrom01 and xm.DayTo01 or xm.DayFrom00 <= xm.DayTo00 and datepart(day,d.InvcDate) not between xm.DayFrom00 and xm.DayTo00) and xm.DayDue01 <= datepart(day,d.InvcDate) then dateadd(day, xm.DayDue01-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate))
  when m.DueType='D' THEN dateadd(day,m.DueIntrv,d.InvcDate) 
  else dateadd(day, m.DueIntrv-datepart(day,dateadd(month,1,d.InvcDate)),dateadd(month,1,d.InvcDate)) end
from 
inserted i
inner join apdoc d on d.docclass=i.docclass and d.refnbr = i.refnbr
inner join terms m on m.termsid = d.terms
inner join xswSBBSTerms xm on xm.TermsID = d.Terms and xm.DayFrom00 <> 0
where i.docclass = 'N' and i.rlsed = 0 and i.LUpd_Prog='04010'

go

