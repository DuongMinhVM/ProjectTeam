
Create Trigger tr_Delete_Customer
On
Customer
For DELETE
AS
If Exists(Select * from Deleted)
Begin
	Declare @SiteCode as varchar(5)
	Select @SiteCode = value From fpt_MST_SS_Parameters
	Where ID = '005'

	Declare @CustID as varchar(10)
	Select @CustID = CustID from Deleted

	If  Not Exists (Select * From fpt_MST_SS_Data_Delete Where Code = Rtrim(@SiteCode)+Rtrim(@CustID) and DataType = 'Customer')
	Begin
		Insert Into fpt_MST_SS_Data_Delete						
		Values (@SiteCode,'Customer',Getdate(),Rtrim(@SiteCode)+Rtrim(@CustID),0,0,'',Rtrim(@CustID),'','','','')
	End
	Else
	Begin
		Update fpt_MST_SS_Data_Delete Set Status = 0 Where Code = Rtrim(@SiteCode)+Rtrim(@CustID)		
	End	
	Update fpt_MST_SS_Data_Baseline Set ProcessType = 'DataDelete' Where Code = Rtrim(@SiteCode)+Rtrim(@CustID) and Status <>2
End
go

