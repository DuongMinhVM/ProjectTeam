
Create Trigger tr_Delete_SOAddress
On
SOAddress
For DELETE
AS
If Exists(Select * from Deleted)
Begin	
	Declare @SiteCode as varchar(5)
	Select @SiteCode = value From fpt_MST_SS_Parameters
	Where ID = '005'

	Declare @CustID as varchar(10)
	Declare @ShiptoID as varchar(5)
	Select @CustID=CustID, @ShiptoID=ShipToID from Deleted
	
	If  Not Exists (Select * From fpt_MST_SS_Data_Delete Where Code = Rtrim(@SiteCode)+Rtrim(@CustID) + '$' + Rtrim(@ShiptoID) and DataType = 'ShipAddr' )
	Begin
		Insert Into fpt_MST_SS_Data_Delete						
	Values (@SiteCode,'ShipAddr',Getdate(),Rtrim(@SiteCode)+Rtrim(@CustID) + '$' + Rtrim(@ShiptoID) ,0,0,'',Rtrim(@CustID),Rtrim(@ShiptoID),'','','')
	End
	Else
	Begin
		Update fpt_MST_SS_Data_Delete Set Status = 0 Where Code = Rtrim(@SiteCode)+Rtrim(@CustID) + '$' + Rtrim(@ShiptoID)		
	End
	Update fpt_MST_SS_Data_Baseline Set ProcessType = 'DataDelete' Where Code = Rtrim(@SiteCode)+Rtrim(@CustID) + '$' + Rtrim(@ShiptoID) and Status <>2
End
go

