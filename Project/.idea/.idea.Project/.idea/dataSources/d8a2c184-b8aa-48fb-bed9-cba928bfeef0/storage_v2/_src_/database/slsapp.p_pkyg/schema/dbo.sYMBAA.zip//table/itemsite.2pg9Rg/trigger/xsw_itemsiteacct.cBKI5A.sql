
create trigger xsw_ItemSiteAcct ON [dbo].[ItemSite] 
FOR INSERT
AS
Update s set s.invtAcct = m.DfltInvtAcct, LeadTime = 0 from inserted I
inner join ItemSite S on i.CpnyID = S.CpnyID and I.SiteID = s.SiteID and i.InvtID = s.InvtID
inner join Site m on i.CpnyID = m.CpnyID and i.SiteID = m.SiteID and m.DfltInvtAcct <> ''

insert ItemSite(ABCCode, AllocQty, AvgCost, BMIAvgCost, BMIDirStdCst, BMIFOvhStdCst, BMILastCost, BMIPDirStdCst, BMIPFOvhStdCst, BMIPStdCst, 
BMIPVOvhStdCst, BMIStdCost, BMITotCost, BMIVOvhStdCst, Buyer, COGSAcct, COGSSub, CountStatus, CpnyID, Crtd_DateTime, Crtd_Prog, Crtd_User, 
CycleID, DfltPOUnit, DfltSOUnit, DfltWhseLoc/*4.5*/, DirStdCst, EOQ, FOvhStdCst, InvtAcct, InvtID, InvtSub, LastBookQty, LastCost, LastCountDate, 
LastPurchaseDate, LastPurchasePrice, LastStdCost, LastVarAmt, LastVarPct, LastVarQty, LastVendor, LeadTime, LUpd_DateTime, LUpd_Prog, 
LUpd_User, MaxOnHand, MfgClassID/*4.5*/, MfgLeadTime, MoveClass, NoteID, PDirStdCst, PFOvhStdCst, PrimVendID, ProdMgrID, PStdCostDate, PStdCst, PVOvhStdCst, 
QtyAlloc, QtyAvail, QtyCustOrd, QtyInTransit, QtyNotAvail, QtyOnBO, QtyOnDP, QtyOnHand, QtyOnKitAssyOrders, QtyOnPO, QtyOnTransferOrders, 
QtyShipnotInv, QtyWOFirmDemand, QtyWOFirmSupply, QtyWORlsedDemand, QtyWORlsedSupply, ReordInterval, ReordPt, ReordPtCalc, ReordQty, 
ReordQtyCalc, ReplMthd, S4Future01, S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09, 
S4Future10, S4Future11, S4Future12, SafetyStk, SafetyStkCalc, SalesAcct, SalesSub, SecondVendID, Selected, ShipNotInvAcct, ShipNotInvSub, 
SiteID, StdCost, StdCostDate, StkItem, TotCost, Turns, UsageRate, User1, User2, User3, User4, User5, User6, User7, User8, VOvhStdCst, YTDUsage)
select i.ABCCode, 0, 0, 0, i.BMIDirStdCst, i.BMIFOvhStdCst, 0, i.BMIPDirStdCst, i.BMIPFOvhStdCst, i.BMIPStdCst, 
i.BMIPVOvhStdCst, i.BMIStdCost, 0, i.BMIVOvhStdCst, i.Buyer, i.COGSAcct, i.COGSSub, i.CountStatus, i.CpnyID, i.Crtd_DateTime, i.Crtd_Prog, i.Crtd_User, 
i.CycleID, i.DfltPOUnit, i.DfltSOUnit, ''/*4.5*/, i.DirStdCst, i.EOQ, i.FOvhStdCst, t.DfltInvtAcct, i.InvtID, i.InvtSub, 0, 0, i.LastCountDate, 
0, 0, i.LastStdCost, i.LastVarAmt, i.LastVarPct, i.LastVarQty, i.LastVendor, i.LeadTime, i.LUpd_DateTime, i.LUpd_Prog, 
i.LUpd_User, i.MaxOnHand, i.MfgClassID/*4.5*/, i.MfgLeadTime, i.MoveClass, 0, i.PDirStdCst, i.PFOvhStdCst, i.PrimVendID, i.ProdMgrID, i.PStdCostDate, i.PStdCst,i.PVOvhStdCst, 
0, 0, 0, 0,0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, i.ReordInterval, i.ReordPt, i.ReordPtCalc, i.ReordQty, 
i.ReordQtyCalc, i.ReplMthd, i.S4Future01, i.S4Future02, i.S4Future03, i.s4Future04, i.S4Future05, i.S4Future06, i.S4Future07, i.S4Future08, i.S4Future09, 
i.S4Future10, i.S4Future11, i.S4Future12, i.SafetyStk, i.SafetyStkCalc, i.SalesAcct, i.SalesSub, i.SecondVendID, i.Selected, i.ShipNotInvAcct, i.ShipNotInvSub, 
t.SiteID, i.StdCost, i.StdCostDate, i.StkItem,0, i.Turns, i.UsageRate, i.User1, i.User2, i.User3, i.User4, i.User5, i.User6, i.User7, i.User8, i.VOvhStdCst, i.YTDUsage
from inserted i inner join site t on i.siteID <> t.SiteID and t.DfltInvtAcct <> '' 
left join itemsite e on i.INvtID = e.INvtID and e.siteID = t.SiteID where e.SiteID is null
go

