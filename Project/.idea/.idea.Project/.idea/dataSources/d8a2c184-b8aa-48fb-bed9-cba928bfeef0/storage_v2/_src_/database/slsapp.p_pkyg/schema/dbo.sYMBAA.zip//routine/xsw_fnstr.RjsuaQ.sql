
create function xsw_fnSTR(@f float, @l smallint = 10, @d smallint = 0) RETURNS varchar(25)
AS
BEGIN
	DECLARE @ret varchar(25), @pref varchar(25)
	SET @ret = ltrim(str(@f, @l, @d))
	if len(@ret) < @l
		SET @ret = stuff(@ret, CASE left(@ret, 1) WHEN '-' THEN 2 ELSE 1 END, 0, replicate('0', @l - len(@ret)))
	RETURN @ret
END
go

