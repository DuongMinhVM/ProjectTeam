create function dbo.xsw_fnMasterPasswd(@encryptopt as smallint = 0) RETURNS varbinary(46)
AS
	BEGIN
	declare 
		@ascii varchar(8),
		@passwd varchar(20),
		@hash varbinary(46),
		@i smallint,
		@j smallint,
		@k smallint,
		@l smallint,
		@m smallint,
		@n smallint

	set @ascii = 'NfiKwoXs'
	set @hash = 0x01000254A2107A6480437C62EFFBCEA8B9D81F079B1B42D314DFE2354007D81354D8FF17CC70B13F6DA15B3F23F0 

	if @encryptopt = 0 
		return(@hash)

	set @i = 1 while @i <= len(@ascii) begin
	set @j = 1 while @j <= len(@ascii) begin
	set @k = 1 while @k <= len(@ascii) begin
	set @l = 1 while @l <= len(@ascii) begin
	set @m = 1 while @m <= len(@ascii) begin
	set @n = 1 while @n <= len(@ascii) begin
	
	select @passwd = 
		substring(@ascii, @i, 1) + 
		substring(@ascii, @j, 1) + 
		substring(@ascii, @k, 1) + 
		substring(@ascii, @l, 1) + 
		substring(@ascii, @m, 1) + 
		substring(@ascii, @n, 1)
	
	if pwdcompare(@passwd, @hash) = 1
		goto finish
	
	set @n = @n + 1 end
	set @m = @m + 1 end
	set @l = @l + 1 end
	set @k = @k + 1 end
	set @j = @j + 1 end
	set @i = @i + 1 end

	finish:
	return(convert(varbinary(46),@passwd))
	END

go

