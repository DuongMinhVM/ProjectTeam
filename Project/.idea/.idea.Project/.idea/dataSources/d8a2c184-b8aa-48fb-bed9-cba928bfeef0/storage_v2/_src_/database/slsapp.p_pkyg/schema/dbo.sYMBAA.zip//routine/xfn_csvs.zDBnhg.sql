
create function xfn_CsvS (@a varchar(60)) RETURNS varchar(64) AS
BEGIN 
        RETURN '"' + isnull(replace(replace(ltrim(rtrim(@a)), '"', ''''), ',', '_'), '') + '"' 
END
go

