
create trigger xsw_ggIntran_MUOMSync ON [Intran] 
for INSERT
as

Update r set r.User1 = case when i.Qty < 0 then '-' else '' end
            + case when t.UOM3 = '' then '' 
                    else convert(varchar,convert(int,floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end) / (case when t.multdiv3 = "M" then t.cnvFact3 else 1/t.cnvFact3 end))))) + case when t.UOM3 = i.Unitdesc then '' else '/' end
               end 
            + case when (t.UOM2 = '' or t.UOM3 = i.Unitdesc)  then '' 
                   else convert(varchar,convert(int,floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end) - (case when t.UOM3 = '' then 0 else (case when t.multdiv3 = "M" then t.cnvFact3 else 1/t.cnvFact3 end)* floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end)/(case when t.multdiv3 = "M" then t.cnvFact3 else 1/t.cnvFact3 end))) end))/(case when t.multdiv2 = "M" then t.cnvFact2 else 1/t.cnvFact2 end)))) + case when t.UOM2 = i.Unitdesc then '' else '/' end
              end 
            + case when (t.UOM1 = '' or t.UOM3 = i.Unitdesc or t.UOM2 = i.Unitdesc) then '' 
                   else convert(varchar,convert(int,floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end) - (case when t.UOM2 = '' then 0 else (case when t.multdiv2 = "M" then t.cnvFact2 else 1/t.cnvFact2 end)* floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end)/(case when t.multdiv2 = "M" then t.cnvFact2 else 1/t.cnvFact2 end))) end))/(case when t.multdiv1 = "M" then t.cnvFact1 else 1/t.cnvFact1 end)))) + case when t.UOM1 = i.Unitdesc then '' else '/' end
              end 
            + case when (t.UOM1 = t.UOM or t.UOM3 = i.Unitdesc or t.UOM2 = i.Unitdesc or t.UOM1 = i.Unitdesc) then '' 
                   else convert(varchar,convert(int,floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end) - (case when t.UOM1 = '' then 0 else (case when t.multdiv1 = "M" then t.cnvFact1 else 1/t.cnvFact1 end)*floor((abs(i.Qty * case when i.UnitMultDiv = 'D' then 1/i.CnvFact else i.CnvFact end)/(case when t.multdiv1 = "M" then t.cnvFact1 else 1/t.cnvFact1 end))) end)))))
           END
from inserted i inner loop join intran r on i.User1 = '' and i.RecordID = r.RecordID
inner loop join xswInvtConvUnit t on t.INvtID = i.invtid
option (force order)
go

