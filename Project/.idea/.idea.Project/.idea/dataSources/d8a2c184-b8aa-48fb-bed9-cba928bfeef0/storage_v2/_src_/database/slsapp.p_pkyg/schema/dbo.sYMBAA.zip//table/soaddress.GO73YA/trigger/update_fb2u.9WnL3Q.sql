CREATE TRIGGER Update_FB2U  ON [dbo].[SOAddress] 
FOR  INSERT 
AS
Declare @Max_FB2U  int
Declare @FB2U varchar(10)
Declare @DistributorCode varchar(6)
select @Max_FB2U = max(cast((SubString(RTrim(LTrim(user6)),7,4)) as int))  from soaddress
Select distinct @DistributorCode =SubString(RTrim(LTrim(user6)),1,6) from soaddress where user6 <> ''
	Set @Max_FB2U = @Max_FB2U + 1
	Set @FB2U = @DistributorCode + replicate('0',4- len(cast(@Max_FB2U as varchar))) + cast(@Max_FB2U as varchar)

UPDATE SOAddress SET User6=@FB2U
from inserted i inner loop join soaddress r on  r.user6='' and i.CustID = r.CustID


go

