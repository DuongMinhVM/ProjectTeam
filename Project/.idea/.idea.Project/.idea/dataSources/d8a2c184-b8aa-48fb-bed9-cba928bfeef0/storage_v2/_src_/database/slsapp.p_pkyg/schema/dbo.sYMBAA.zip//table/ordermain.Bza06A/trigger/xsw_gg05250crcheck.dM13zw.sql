

CREATE  TRIGGER xsw_gg05250CrCheck ON dbo.xswSalesOrd
FOR INSERT, UPDATE AS

declare 
  @procid varchar(5),
  @rowcount smallint, 
  @error smallint,
  @msg_admin_hold smallint,
  @msg_credit_hold smallint,
  @msg_overlimit smallint,
  @msg_overdue smallint,
  @msg_combined smallint,
  @h varchar(16),
  @deleted smallint,
  @inserted smallint,
  @SetupID varchar(10)

if exists(select * from inserted where UpdProg in ('OP450', 'OP455')) return
if exists(select * from deleted where UpdProg in ('OP450', 'OP455')) return

set nocount on

select 
  @inserted = case when exists(select * from inserted) then 1 else 0 end,
  @deleted = case when exists(select * from deleted) then 1 else 0 end,
  @procid = 'xxx.r',
  @h = '0123456789abcdef',
  @msg_admin_hold = 30000,
  @msg_credit_hold = 30001,
  @msg_overlimit = 30002,
  @msg_overdue = 30004,
  @msg_combined = 30006,
  @rowcount = 0,
  @error = 0

if @inserted + @deleted = 0 
  return

/*UPDATE Quote Status*/
if @deleted = 0
UPDATE s set 
  s.Status = 'C',
  s.PerClosed = PerNbr
from 
(select distinct CpnyId, AltOrderNbr from inserted where AltOrderType = 'QT') v
inner loop join xswSalesOrd s on s.CpnyId = v.CpnyId and s.OrderNbr = v.AltOrderNbr 
cross join xswSOSetup (nolock) OPTION(FORCE ORDER)
if @@error !=0 return

if @deleted = 0
update s set
  s.PerPost = PerNbr
from
inserted i
inner join xswSalesOrd s on s.CpnyID = i.CpnyID and s.OrderNbr = i.OrderNbr
cross join xswSOSetup (nolock) OPTION(FORCE ORDER)
if @@error !=0 return

if update(Status)
update s set
  s.PerClosed = case when i.Status in ('C','L') then PerNbr else '' end
from
inserted i
inner join xswSalesOrd s on s.CpnyID = i.CpnyID and s.OrderNbr = i.OrderNbr
cross join xswSOSetup (nolock) OPTION(FORCE ORDER)
if @@error !=0 return

if update(OrderDate)
update s set 
  s.ULYear = convert(int,year(s.OrderDate)), 
  s.ULWeek = convert(int,w.WeekNbr), 
  s.ULMonth = convert(int,p.PerNbr)
from 
inserted i
inner loop join xswSalesOrd s on s.CpnyID = i.CpnyID and s.OrderNbr = i.OrderNbr
inner join xswUCWeek w on w.Year = convert(char(4),year(s.OrderDate)) and s.Orderdate between w.WeekStart and w.WeekEnd
inner join xswUCPeriod p on p.Year = convert(char(4),year(s.OrderDate)) and s.Orderdate between p.PerStart and p.PerEnd OPTION(FORCE ORDER)
if @@error !=0 return

if @inserted = 1
begin
insert xswwrkprocess (CpnyId, OrderClass, OrderNbr, UserAddress, ProcId, Result, HostId, UserId, 
swfuture1, swfuture2, swfuture3, swfuture4, swfuture5, swfuture6, 
User1, User2, User3, User4, User5, User6, User7, User8)
select i.CpnyID, 'S', i.OrderNbr, host_name(), @ProcID, 0, host_id(),'',
convert(char(1),si.CrCheck), '', '', '', '', '',i.CustID,'',(case when y.ARDocType in ('IN','DM') then 1 else 0 end)*((i.OrdAmt * si.InclCustTotOpenOrd * si.CrCheck) - coalesce(d.OrdAmt * sd.InclCustTotOpenOrd * si.CrCheck, 0)),0,'','','',''
from inserted i
inner loop join xswOrderType y (nolock) on y.OrderType = i.OrderType 
inner loop join xswOrderStatus si (nolock) on si.OrderType = i.OrderType and si.Status = i.Status 
left join deleted d on d.CpnyID = i.CpnyID and d.OrderNbr = i.OrderNbr
left loop join xswOrderStatus sd (nolock) on sd.OrderType = i.OrderType and sd.Status = d.Status 
left loop join xswwrkprocess w (nolock) on w.cpnyid = i.cpnyid and w.orderclass = 'S' and w.ordernbr= i.ordernbr
where (i.UpdProg = y.EditScrnNbr or i.UpdProg = 'HHTIN') and w.OrderNbr IS NULL OPTION (FORCE ORDER)
select @error = @@error, @rowcount = @@rowcount	
if @error != 0 return
end

if @rowcount > 0
update w
  set User4 = User3 + coalesce((select sum(User3) from xswwrkprocess p where useraddress = host_name() and hostid = host_id() and p.CpnyID = w.CpnyID and p.OrderClass = 'S' and p.User1 = w.User1 and p.OrderNbr < w.OrderNbr),0)
from xswwrkprocess w 
where useraddress = host_name() and hostid = host_id() and OrderClass = 'S' and SWFuture1 = '1'
if @@error != 0 return

if @rowcount > 0
update w set 
w.result  = case 
  when c_edi.CreditRule = 'X' then @MSG_ADMIN_HOLD
  when c_edi.CreditRule = 'H' then @MSG_CREDIT_HOLD
  when c_edi.CreditRule in ('A', 'B') then 
    case when (coalesce(b.currbal + b.futurebal + b.totopenord, 0) + w.User4) * (case when c.crlmt = 0 then 0 else 1 end) * (case when w.User3 = 0 then 0 else 1 end) > (case when ar.overlimittype = 'A' then (c.crlmt + ar.overlimitamt) else c.crlmt * (1+ ar.overlimitamt/100) end)
      then @MSG_OVERLIMIT  else 0 end |
    case when c_edi.CreditRule = 'B' and exists(select * from ARDoc r (nolock) where r.cpnyid = w.cpnyid and r.custid = w.user1 and r.rlsed = 1 and r.opendoc = 1 and r.duedate <= dateadd(day, -1*ar.dayspastdue, getdate()))
      then @MSG_OVERDUE else 0 end
  else 0 end
from xswwrkprocess w
inner join customer c (nolock) on c.custid = w.user1 
inner join customeredi c_edi (nolock) on c_edi.custid = w.user1 and c_edi.creditrule not in ('N', 'C')
left join xsw_vpARbalances b (nolock) on b.cpnyid = w.cpnyid and b.custid = w.user1
cross join ARSetup ar (nolock)
where w.UserAddress = host_name() and w.HostID = host_id() and w.OrderClass = 'S' and w.SWFuture1 = '1' OPTION(FORCE ORDER)
select @error = @@error, @rowcount = @@rowcount	
if @error != 0 return

if @rowcount > 0
update s 
  set s.Status = case when w.Result = @MSG_ADMIN_HOLD then 'H' else 'R' end
from inserted i 
inner join xswwrkprocess w (nolock) on w.CpnyID = i.CpnyID and w.orderclass = 'S' and w.OrderNbr = i.OrderNbr 
inner join xswSalesOrd s on s.CpnyID = i.CpnyID and s.OrderNbr = i.OrderNbr 
where w.UserAddress = host_name() and w.HostID = host_id() and w.Result != 0 OPTION(FORCE ORDER) 
if @@error != 0 return

if update(CrtdProg) or update(UpdProg) or update(Status)
if @deleted = 1
update s set 
  s.crtdprog = d.crtdprog,
  s.updprog = i.crtdprog,
  s.ARRefNbr = case when i.Status = 'L' then '' else s.ARRefNbr end,
  s.ARDocDate = case when i.Status = 'L' then '' else s.ARDocDate end
from inserted i
inner loop join deleted d on d.CpnyId = i.CpnyId and d.OrderNbr = i.OrderNbr
inner loop join xswSalesOrd s on s.CpnyId = i.CpnyId and s.OrderNbr = i.OrderNbr
where i.CrtdProg != d.CrtdProg OPTION (FORCE ORDER)
if @@error != 0 return 

if update(cpnyid) or update(custid)
insert AR_Balances(AgeBal00, AgeBal01, AgeBal02, AgeBal03, AgeBal04, AvgDayToPay, CpnyID, CrLmt, Crtd_DateTime, Crtd_Prog, Crtd_User, 
CurrBal, CuryID, CuryPromoBal, CustID, FutureBal, LastActDate, LastAgeDate, LastFinChrgDate, LastInvcDate, LastStmtBal00, LastStmtBal01, 
LastStmtBal02, LastStmtBal03, LastStmtBal04, LastStmtBegBal, LastStmtDate, LUpd_DateTime, LUpd_Prog, LUpd_User, NbrInvcPaid, NoteID, 
PaidInvcDays, PerNbr, PromoBal, S4Future01, S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09, 
S4Future10, S4Future11, S4Future12, TotOpenOrd, TotPrePay, User1, User2, User3, User4, User5, User6, User7, User8, 
/*60*/AccruedRevAgeBal00, AccruedRevAgeBal01, AccruedRevAgeBal02, AccruedRevAgeBal03, AccruedRevAgeBal04, AccruedRevBal, TotShipped)
select 0, 0, 0, 0, 0, 0, i.CpnyID, 0, getdate(), max(i.UpdProg), max(i.UpdUser), 
0, max(coalesce(nullif(c.CuryID,''), BaseCuryID)), 0, i.CustID, 0, max(i.OrderDate), '', '', '', 0, 0, 
0, 0, 0, 0, '', getdate(), max(i.UpdProg), max(i.UpdUser), 0, 0, 
0, max(c.PerNbr), 0, '', '', 0, 0, 0, 0, '', '', 0, 
0, '', '', 0, 0, '', '', 0, 0, '', '', '', '',
/*60*/0, 0, 0, 0, 0, 0, 0
from inserted i
inner join Customer c (nolock) on c.CustID = i.CustID
cross join GLSetup (nolock)
where not exists(select * from AR_Balances b (nolock) where b.CpnyID = i.CpnyID and b.CustID = i.CustID)
group by i.CpnyID, i.CustID
if @@error != 0 return 

update b set 
	b.totopenord = b.totopenord + v.totopenord,
	b.TotShipped = b.TotShipped
from 
	(select i.CpnyID, i.CustID, TotOpenOrd = sum((case when y.ARDocType = 'CM' then 0 else 1 end) * (coalesce(i.OrdAmt * si.InclCustTotOpenOrd, 0) - coalesce(d.OrdAmt * sd.InclCustTotOpenOrd, 0)))
	from inserted n 
	inner loop join xswSalesOrd i on i.CpnyID = n.CpnyID and i.OrderNbr = n.OrderNbr
	left loop join deleted d on d.CpnyID = i.CpnyID and d.OrderNbr = i.OrderNbr
	inner loop join xswOrderStatus si (nolock) on si.OrderType = i.OrderType and si.Status = i.Status 
	left loop join xswOrderStatus sd (nolock) on sd.OrderType = d.OrderType and sd.Status = d.Status 
	inner loop join xswOrderType y (nolock) on y.OrderType = i.OrderType
	where 
	y.ARDocType != 'NA' and abs(coalesce(i.OrdAmt * si.InclCustTotOpenOrd, 0) - coalesce(d.OrdAmt * sd.InclCustTotOpenOrd, 0)) > 0.00000001
	group by i.CpnyID, i.CustID) v
inner loop join ar_balances b on b.CpnyID = v.CpnyID and b.CustID = v.CustID OPTION (FORCE ORDER)
if @@error != 0 return 

if update(Status) 
if @deleted = 1 
if exists(select * from deleted d inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and i.Status != d.Status)
  begin
  /*invoke xsw_ggSlsOrdDet_UpdateBL*/
  update det set 
    det.Status = i.Status
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status
  inner loop join xswSlsOrdDet det on det.CpnyId = d.CpnyId and det.OrderNbr = d.OrderNbr OPTION (FORCE ORDER)
  if @@error != 0 return

  /*invoke xsw_ggSlsOrdlot_UpdateLotSerT*/
  update lot set 
    lot.Status = i.Status
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status
  inner loop join xswSlsOrdLot lot on lot.CpnyId = d.CpnyId and lot.OrderNbr = d.OrderNbr OPTION (FORCE ORDER)
  if @@error != 0 return

  /*invoke xsw_ggSlsOrdDisc_UpdateAlloc*/
  update disc set 
    disc.Status = i.Status
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status
  inner loop join xswSlsOrdDisc disc on disc.CpnyId = d.CpnyId and disc.OrderNbr = d.OrderNbr OPTION (FORCE ORDER)
  if @@error != 0 return

   /*invoke xsw_gg05010CrCheck2*/
  update p set 
    p.SWFuture1 = u.SWFuture1
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status 
  inner loop join xswOrderStatus u (nolock) on u.OrderType = i.OrderType and u.Status = i.Status 
  inner loop join xswSlsOrdDsp p on p.CpnyId = i.CpnyId and p.OrderNbr = i.OrderNbr 
  where u.SWFuture1 != '' OPTION (FORCE ORDER)
  if @@error != 0 return

  /*invoke xsw_ggDspOrdDet_UpdateSO*/
  update det set 
    det.Status = u.SWFuture1
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status
  inner loop join xswOrderStatus u (nolock) on u.OrderType = i.OrderType and u.Status = i.Status 
  inner loop join xswDspOrdDet det on det.CpnyId = i.CpnyId and det.AltOrderNbr = i.OrderNbr 
  where u.SWFuture1 != '' OPTION (FORCE ORDER)
  if @@error != 0 return

   /*invoke xsw_ggDspOrdLot_UpdateLotSerT*/
  update lot set 
    lot.Status = u.SWFuture1
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status 
  inner loop join xswOrderStatus u (nolock) on u.OrderType = i.OrderType and u.Status = i.Status 
  inner loop join xswDspOrdLot lot on lot.CpnyId = i.CpnyId and lot.OrderNbr = i.OrderNbr 
  where u.SWFuture1 != '' OPTION (FORCE ORDER)
  if @@error != 0 return

  /*invoke xsw_ggDspOrdDisc_UpdateAlloc*/
  update disc set 
    disc.Status = u.SWFuture1
  from deleted d
  inner loop join xswSalesOrd i on i.CpnyId = d.CpnyId and i.OrderNbr = d.OrderNbr and d.Status != i.Status
  inner loop join xswOrderStatus u (nolock) on u.OrderType = i.OrderType and u.Status = i.Status 
  inner loop join xswDspOrdDisc disc on disc.CpnyId = i.CpnyId and disc.OrderNbr = i.OrderNbr 
  where u.SWFuture1 != '' OPTION (FORCE ORDER)

  end

if @deleted = 1
delete r 
from deleted d
left join inserted i on i.CpnyID = d.CpnyID and i.OrderNbr = d.OrderNbr and i.ARRefNbr = d.ARRefNbr
inner loop join RefNbr r on d.arrefnbr = r.refnbr 
inner loop join xswOrderType y (nolock) on y.OrderType = d.OrderType 
where y.DspRule = '1' and d.ARRefnbr <> '' and isnull(i.Status,'L') = 'L' OPTION (FORCE ORDER)
if @@error != 0 return 
   
if @inserted = 1
insert refnbr (Crtd_DateTime, Crtd_Prog, Crtd_User, DocType, LUpd_DateTime, LUpd_Prog, LUpd_User, RefNbr, S4Future01,
               S4Future02, S4Future03, S4Future04, S4Future05, S4Future06, S4Future07, S4Future08, S4Future09,
               S4Future10, S4Future11, S4Future12, User1, User2, User3, User4, User5, User6, User7, User8)
select getdate(), i.CrtdProg, i.CrtdUser, '', getdate(), i.CrtdProg, i.CrtdUser, i.ARRefNbr, '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, 0, '', '', 0, 0
from inserted i
left join deleted d on d.CpnyID = i.CpnyID and d.OrderNbr = i.OrderNbr and d.ARRefNbr = i.ARRefNbr
inner loop join xswOrderType y (nolock) on y.OrderType = i.OrderType 
where i.Status != 'L' and y.DspRule = '1' and i.ARRefNbr <> '' and d.ARRefNbr is null OPTION (FORCE ORDER)
if @@error != 0 return


go

