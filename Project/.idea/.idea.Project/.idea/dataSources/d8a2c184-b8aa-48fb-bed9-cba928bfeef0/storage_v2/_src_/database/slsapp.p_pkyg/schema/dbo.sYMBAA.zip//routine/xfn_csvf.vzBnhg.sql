
create function xfn_CsvF (@f float, @d smallint) RETURNS varchar(25) AS
BEGIN 
        RETURN '"' + isnull(ltrim(str(round(@f, @d), 36, @d)), '') + '"' 
END
go

