
CREATE Function POE_CmpCodeDate(@OrderCode char(10), @Date datetime)
	Returns int
AS
Begin
	Declare @OrderDate char(4)
	Declare @strDate char(4)
	Declare @Ret int

	Set @strDate = 	cast(Right(convert(varchar, year(@Date)),1) as varchar) + 
			Case Month(@Date) 
				When 10 Then 'A'
				When 11 Then 'B'
				When 12 Then 'C'
				Else Cast(Month(@Date) as varchar)
			End + 
			Case 
				When Day(@Date)<10 Then '0' + Cast(Day(@Date) as varchar)
				Else Cast(Day(@Date) as varchar)
			End
	Set @OrderDate = Right(Left(@OrderCode,7),4)
	If (@OrderDate = @strDate)
		Set @Ret = 1
	Else
		Set @Ret = 0

	Return (@Ret)
End


go

