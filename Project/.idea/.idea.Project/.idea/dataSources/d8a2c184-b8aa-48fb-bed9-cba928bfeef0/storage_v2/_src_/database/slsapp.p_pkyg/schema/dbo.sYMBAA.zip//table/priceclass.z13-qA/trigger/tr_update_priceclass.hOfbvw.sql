
Create Trigger tr_Update_PriceClass
On
PriceClass
For UPDATE,INSERT
AS
If Update(Descr)
Begin
	Update PriceClass set user4 = 0
	Where PriceClassID in (Select PriceClassID from Inserted)
End
go

