
create function xsw_ArchChunkSize(@total float, @max_iterations float, @min_size int) RETURNS int
AS
BEGIN
        DECLARE @size int
        SET @size = ceiling(@total / @max_iterations)
        IF @size < @min_size
                SET @size = @min_size
        RETURN @size
END
go

