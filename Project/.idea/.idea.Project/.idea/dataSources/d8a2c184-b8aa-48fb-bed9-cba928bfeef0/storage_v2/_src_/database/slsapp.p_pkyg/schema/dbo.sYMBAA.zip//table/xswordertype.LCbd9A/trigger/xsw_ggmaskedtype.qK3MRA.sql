
CREATE	TRIGGER	xsw_ggMaskedType ON xswOrderType FOR INSERT,UPDATE,DELETE

AS

if not (
  update(DfltArAcct) or
  update(DfltArSub) or
  update(DfltCOGSAcct) or
  update(DfltCOGSSub) or
  update(DfltFreeCOGSAcct) or
  update(DfltFreeCOGSSub) or
  update(DfltLineDiscAcct) or
  update(DfltLineDiscSub) or
  update(DfltSlsAcct) or
  update(DfltSlsSub) or
  update(DfltVolumeDiscAcct) or
  update(DfltVolumeDiscSub) or   
  update(DfltFreightAcct) or
  update(DfltFreightSub) or
  update(DfltMiscAcct) or
  update(DfltMiscSub))
    return

set nocount on

DELETE	xswMaskedType
FROM	inserted d
WHERE	xswMaskedType.OrderType=d.OrderType
IF @@ERROR<>0 BEGIN ROLLBACK RETURN END

INSERT	xswMaskedType
SELECT	w.OrderType, SlsType='GI', INDocType, n.DfltInvtAcct, n.DfltInvtSub,
	SlsAcct=CASE INDocType WHEN 'TR' THEN INClearingAcct ELSE
	CASE SUBSTRING(w.DfltSlsAcct,1,1) WHEN '&' THEN '&1' ELSE w.DfltSlsAcct END END,
	SlsSub=CASE INDocType WHEN 'TR' THEN INClearingSub ELSE
	CASE SUBSTRING(w.DfltSlsSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(w.DfltSlsSub,1,SegLength00) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(w.DfltSlsSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(w.DfltSlsSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(w.DfltSlsSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(w.DfltSlsSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(w.DfltSlsSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(w.DfltSlsSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(w.DfltSlsSub,MaskStart07,SegLength07) END END,
	COGSAcct=CASE INDocType WHEN 'TR' THEN '' ELSE
	CASE SUBSTRING(w.DfltCOGSAcct,1,1) WHEN '&' THEN '&1' ELSE w.DfltCOGSAcct END END,
	COGSSub=CASE INDocType WHEN 'TR' THEN '' ELSE
	CASE SUBSTRING(w.DfltCOGSSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(w.DfltCOGSSub,1,SegLength00) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(w.DfltCOGSSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(w.DfltCOGSSub,MaskStart07,SegLength07) END END,
	SlsAcctStart=((8+(1+CHARINDEX(w.DfltSlsAcct,'&C&T&A&I&L&S'))/2)%9)*10+1,
	SlsSubStart00=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,2,1),'&C&T&A&I&L&S'))/2)%9)*24+1,
	SlsSubStart01=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart01+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart01,
	SlsSubStart02=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart02+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart02,
	SlsSubStart03=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart03+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart03,
	SlsSubStart04=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart04+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart04,
	SlsSubStart05=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart05+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart05,
	SlsSubStart06=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart06+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart06,
	SlsSubStart07=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart07+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart07,
	COGSAcctStart=((6+(1+CHARINDEX(w.DfltCOGSAcct,'&C&T&A&I&L&S'))/2)%7)*10+1,
	COGSSubStart00=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,2,1),'&C&T&A&I&L&S'))/2)%7)*24+1,
	COGSSubStart01=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart01+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart01,
	COGSSubStart02=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart02+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart02,
	COGSSubStart03=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart03+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart03,
	COGSSubStart04=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart04+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart04,
	COGSSubStart05=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart05+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart05,
	COGSSubStart06=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart06+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart06,
	COGSSubStart07=((6+(1+CHARINDEX(SUBSTRING(w.DfltCOGSSub,MaskStart07+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart07,
	SlsSubLength00=CASE WHEN CHARINDEX(w.DfltSlsSub,'&C&T&A&I&L&S')>0 AND LEN(w.DfltSlsSub)=2 THEN 24 ELSE SegLength00 END,
	COGSSubLength00=CASE WHEN CHARINDEX(w.DfltCOGSSub,'&C&T&A&I&L&S')>0 AND LEN(w.DfltCOGSSub)=2 THEN 24 ELSE SegLength00 END,
	SegLength00,SegLength01,SegLength02,SegLength03,SegLength04,SegLength05,SegLength06,SegLength07,
	Seperator00,Seperator01,Seperator02,Seperator03,Seperator04,Seperator05,Seperator06,
	Ord=0
FROM	Inserted w CROSS JOIN INSetup n CROSS JOIN xsw_vpMaskedDef f

UNION ALL

SELECT	w.OrderType, SlsType='GF', INDocType, n.DfltInvtAcct, n.DfltInvtSub,
	SlsAcct=CASE INDocType WHEN 'TR' THEN INClearingAcct ELSE
	CASE SUBSTRING(w.DfltSlsAcct,1,1) WHEN '&' THEN '&1' ELSE w.DfltSlsAcct END END,
	SlsSub=CASE INDocType WHEN 'TR' THEN INClearingSub ELSE
	CASE SUBSTRING(w.DfltSlsSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(w.DfltSlsSub,1,SegLength00) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(w.DfltSlsSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(w.DfltSlsSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(w.DfltSlsSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(w.DfltSlsSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(w.DfltSlsSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(w.DfltSlsSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(w.DfltSlsSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(w.DfltSlsSub,MaskStart07,SegLength07) END END,
	COGSAcct=CASE INDocType WHEN 'TR' THEN '' ELSE
	CASE SUBSTRING(w.DfltFreeCOGSAcct,1,1) WHEN '&' THEN '&1' ELSE w.DfltFreeCOGSAcct END END,
	COGSSub=CASE INDocType WHEN 'TR' THEN '' ELSE
	CASE SUBSTRING(w.DfltFreeCOGSSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(w.DfltFreeCOGSSub,1,SegLength00) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(w.DfltFreeCOGSSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(w.DfltFreeCOGSSub,MaskStart07,SegLength07) END END,
	SlsAcctStart=((8+(1+CHARINDEX(w.DfltSlsAcct,'&C&T&A&I&L&S'))/2)%9)*10+1,
	SlsSubStart00=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,2,1),'&C&T&A&I&L&S'))/2)%9)*24+1,
	SlsSubStart01=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart01+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart01,
	SlsSubStart02=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart02+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart02,
	SlsSubStart03=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart03+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart03,
	SlsSubStart04=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart04+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart04,
	SlsSubStart05=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart05+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart05,
	SlsSubStart06=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart06+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart06,
	SlsSubStart07=((8+(1+CHARINDEX(SUBSTRING(w.DfltSlsSub,MaskStart07+1,1),'&C&T&A&I&L&S'))/2)%9)*24+SegStart07,
	COGSAcctStart=((6+(1+CHARINDEX(w.DfltFreeCOGSAcct,'&C&T&A&I&L&S'))/2)%7)*10+1,
	COGSSubStart00=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,2,1),'&C&T&A&I&L&S'))/2)%7)*24+1,
	COGSSubStart01=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart01+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart01,
	COGSSubStart02=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart02+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart02,
	COGSSubStart03=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart03+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart03,
	COGSSubStart04=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart04+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart04,
	COGSSubStart05=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart05+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart05,
	COGSSubStart06=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart06+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart06,
	COGSSubStart07=((6+(1+CHARINDEX(SUBSTRING(w.DfltFreeCOGSSub,MaskStart07+1,1),'&C&T&A&I&L&S'))/2)%7)*24+SegStart07,
	SlsSubLength00=CASE WHEN CHARINDEX(w.DfltSlsSub,'&C&T&A&I&L&S')>0 AND LEN(w.DfltSlsSub)=2 THEN 24 ELSE SegLength00 END,
	COGSSubLength00=CASE WHEN CHARINDEX(w.DfltFreeCOGSSub,'&C&T&A&I&L&S')>0 AND LEN(w.DfltFreeCOGSSub)=2 THEN 24 ELSE SegLength00 END,
	SegLength00,SegLength01,SegLength02,SegLength03,SegLength04,SegLength05,SegLength06,SegLength07,
	Seperator00,Seperator01,Seperator02,Seperator03,Seperator04,Seperator05,Seperator06,
	Ord=0
FROM	Inserted w CROSS JOIN INSetup n CROSS JOIN xsw_vpMaskedDef f

UNION ALL

SELECT	w.OrderType, SlsType='FR', INDocType, DfltInvtAcct='', DfltInvtSub='',
	SlsAcct=CASE SUBSTRING(DfltFreightAcct,1,1) WHEN '&' THEN '&1' ELSE DfltFreightAcct END,
	SlsSub=CASE SUBSTRING(DfltFreightSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(DfltFreightSub,1,SegLength00) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(DfltFreightSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(DfltFreightSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(DfltFreightSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(DfltFreightSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(DfltFreightSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(DfltFreightSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(DfltFreightSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(DfltFreightSub,MaskStart07,SegLength07) END,
	COGSAcct='',
	COGSSub='',
	SlsAcctStart=((8+(1+CHARINDEX(DfltFreightAcct,'&C&T&A######&V'))/2)%9)*10+1,
	SlsSubStart00=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,2,1),'&C&T&A######&V'))/2)%9)*24+1,
	SlsSubStart01=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart01+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart01,
	SlsSubStart02=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart02+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart02,
	SlsSubStart03=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart03+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart03,
	SlsSubStart04=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart04+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart04,
	SlsSubStart05=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart05+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart05,
	SlsSubStart06=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart06+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart06,
	SlsSubStart07=((8+(1+CHARINDEX(SUBSTRING(DfltFreightSub,MaskStart07+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart07,
	COGSAcctStart=81,
	COGSSubStart00=145,
	COGSSubStart01=145,
	COGSSubStart02=145,
	COGSSubStart03=145,
	COGSSubStart04=145,
	COGSSubStart05=145,
	COGSSubStart06=145,
	COGSSubStart07=145,
	SlsSubLength00=CASE WHEN CHARINDEX(DfltFreightSub,'&C&T&A######&V')>0 AND LEN(DfltFreightSub)=2 THEN 24 ELSE SegLength00 END,
	COGSSubLength00=0,
	SegLength00,SegLength01,SegLength02,SegLength03,SegLength04,SegLength05,SegLength06,SegLength07,
	Seperator00,Seperator01,Seperator02,Seperator03,Seperator04,Seperator05,Seperator06,
	Ord=3
FROM	Inserted w CROSS JOIN  xsw_vpMaskedDef f

UNION ALL

SELECT	w.OrderType, SlsType='MI', INDocType, DfltInvtAcct='', DfltInvtSub='',
	SlsAcct=CASE SUBSTRING(DfltMiscAcct,1,1) WHEN '&' THEN '&1' ELSE DfltMiscAcct END,
	SlsSub=CASE SUBSTRING(DfltMiscSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(DfltMiscSub,1,SegLength00) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(DfltMiscSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(DfltMiscSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(DfltMiscSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(DfltMiscSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(DfltMiscSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(DfltMiscSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(DfltMiscSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(DfltMiscSub,MaskStart07,SegLength07) END,
	COGSAcct='',
	COGSSub='',
	SlsAcctStart=((8+(1+CHARINDEX(DfltMiscAcct,'&C&T&A########&M'))/2)%9)*10+1,
	SlsSubStart00=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,2,1),'&C&T&A########&M'))/2)%9)*24+1,
	SlsSubStart01=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart01+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart01,
	SlsSubStart02=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart02+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart02,
	SlsSubStart03=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart03+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart03,
	SlsSubStart04=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart04+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart04,
	SlsSubStart05=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart05+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart05,
	SlsSubStart06=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart06+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart06,
	SlsSubStart07=((8+(1+CHARINDEX(SUBSTRING(DfltMiscSub,MaskStart07+1,1),'&C&T&A########&M'))/2)%9)*24+SegStart07,
	COGSAcctStart=81,
	COGSSubStart00=145,
	COGSSubStart01=145,
	COGSSubStart02=145,
	COGSSubStart03=145,
	COGSSubStart04=145,
	COGSSubStart05=145,
	COGSSubStart06=145,
	COGSSubStart07=145,
	SlsSubLength00=CASE WHEN CHARINDEX(DfltMiscSub,'&C&T&A########&M')>0 AND LEN(DfltMiscSub)=2 THEN 24 ELSE SegLength00 END,
	COGSSubLength00=0,
	SegLength00,SegLength01,SegLength02,SegLength03,SegLength04,SegLength05,SegLength06,SegLength07,
	Seperator00,Seperator01,Seperator02,Seperator03,Seperator04,Seperator05,Seperator06,
	Ord=2
FROM	Inserted w CROSS JOIN  xsw_vpMaskedDef f

UNION ALL

SELECT	w.OrderType, SlsType='VD', INDocType, DfltInvtAcct='', DfltInvtSub='',
	SlsAcct=CASE SUBSTRING(DfltVolumeDiscAcct,1,1) WHEN '&' THEN '&1' ELSE DfltVolumeDiscAcct END,
	SlsSub=CASE SUBSTRING(DfltVolumeDiscSub,1,1) WHEN '&' THEN '&1' ELSE SUBSTRING(DfltVolumeDiscSub,1,SegLength00) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart01,1) WHEN '&' THEN '&2' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart01,SegLength01) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart02,1) WHEN '&' THEN '&3' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart02,SegLength02) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart03,1) WHEN '&' THEN '&4' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart03,SegLength03) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart04,1) WHEN '&' THEN '&5' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart04,SegLength04) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart05,1) WHEN '&' THEN '&6' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart05,SegLength05) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart06,1) WHEN '&' THEN '&7' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart06,SegLength06) END
	+CASE SUBSTRING(DfltVolumeDiscSub,MaskStart07,1) WHEN '&' THEN '&8' ELSE SUBSTRING(DfltVolumeDiscSub,MaskStart07,SegLength07) END,
	COGSAcct='',
	COGSSub='',
	SlsAcctStart=((8+(1+CHARINDEX(DfltVolumeDiscAcct,'&C&T&A######&V'))/2)%9)*10+1,
	SlsSubStart00=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,2,1),'&C&T&A######&V'))/2)%9)*24+1,
	SlsSubStart01=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart01+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart01,
	SlsSubStart02=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart02+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart02,
	SlsSubStart03=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart03+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart03,
	SlsSubStart04=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart04+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart04,
	SlsSubStart05=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart05+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart05,
	SlsSubStart06=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart06+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart06,
	SlsSubStart07=((8+(1+CHARINDEX(SUBSTRING(DfltVolumeDiscSub,MaskStart07+1,1),'&C&T&A######&V'))/2)%9)*24+SegStart07,
	COGSAcctStart=81,
	COGSSubStart00=145,
	COGSSubStart01=145,
	COGSSubStart02=145,
	COGSSubStart03=145,
	COGSSubStart04=145,
	COGSSubStart05=145,
	COGSSubStart06=145,
	COGSSubStart07=145,
	SlsSubLength00=CASE WHEN CHARINDEX(DfltVolumeDiscSub,'&C&T&A######&V')>0 AND LEN(DfltVolumeDiscSub)=2 THEN 24 ELSE SegLength00 END,
	COGSSubLength00=0,
	SegLength00,SegLength01,SegLength02,SegLength03,SegLength04,SegLength05,SegLength06,SegLength07,
	Seperator00,Seperator01,Seperator02,Seperator03,Seperator04,Seperator05,Seperator06,
	Ord=1
FROM	Inserted w CROSS JOIN  xsw_vpMaskedDef f
IF @@ERROR<>0 BEGIN ROLLBACK RETURN END

go

