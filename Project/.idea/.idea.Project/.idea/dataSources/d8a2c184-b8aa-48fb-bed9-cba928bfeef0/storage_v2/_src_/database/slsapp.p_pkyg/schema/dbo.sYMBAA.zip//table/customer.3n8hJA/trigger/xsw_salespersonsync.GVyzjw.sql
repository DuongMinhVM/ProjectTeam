
create trigger xsw_Salespersonsync ON Customer 
FOR INSERT,UPDATE as

update salesperson
set 
Addr1 = i.Addr1,
Addr2 = i.Addr2,
Attn = i.Attn,
City = i.City, 
CmmnPct = 0, 
Country = i.Country, 
Crtd_DateTime = i.Crtd_DateTime,
Crtd_Prog = i.Crtd_Prog,
Crtd_User = i.Crtd_User,
EMailAddr = i.EMailAddr,
Fax = i.Fax,
LUpd_DateTime = i.LUpd_DateTime,
LUpd_Prog = i.LUpd_Prog,
LUpd_User = i.LUpd_User,
Name = i.Name, 
NoteId = i.NoteId,
PerNbr = i.PerNbr,
Phone = i.phone,
S4Future01 = i.S4Future01,
S4Future02 = i.S4Future02,
S4Future03 = i.S4Future03,
S4Future04 = i.S4Future04,
S4Future05 = i.S4Future05,
S4Future06 = i.S4Future06,
S4Future07 = i.S4Future07,
S4Future08 = i.S4Future08,
S4Future09 = i.S4Future09,
S4Future10 = i.S4Future10,
S4Future11 = i.S4Future11,
S4Future12 = i.S4Future12,
Salut = i.Salut,
State = i.State,
Territory = i.Territory,
Zip = i.zip
From inserted i inner join salesperson s on i.custID = s.SlsperId

if update(user5) 
begin
Insert salesperson
(Addr1,Addr2,Attn,City,CmmnPct,Country,Crtd_DateTime,Crtd_Prog,Crtd_User,EMailAddr,Fax,
LUpd_DateTime,LUpd_Prog,LUpd_User,Name,NoteId,PerNbr,Phone,S4Future01,S4Future02,
S4Future03,S4Future04,S4Future05,S4Future06,S4Future07,S4Future08,S4Future09,S4Future10,
S4Future11,S4Future12,Salut,SlsperId,State,Territory,
User1,User2,User3,User4,User5,User6,User7,User8,Zip)
Select 
i.Addr1,i.Addr2,i.Attn,i.City,0,i.Country,i.Crtd_DateTime,i.Crtd_Prog,i.Crtd_User,i.EMailAddr,i.Fax,
i.LUpd_DateTime,i.LUpd_Prog,i.LUpd_User,i.Name,i.NoteId,i.PerNbr,i.Phone,i.S4Future01,i.S4Future02,
i.S4Future03,i.S4Future04,i.S4Future05,i.S4Future06,i.S4Future07,i.S4Future08,i.S4Future09,i.S4Future10,
i.S4Future11,i.S4Future12,i.Salut,i.CustId,i.State,i.Territory,
i.User1,i.User2,i.User3,i.User4,i.User5,i.User6,i.User7,i.User8,i.Zip
From inserted i left join salesperson s on i.custID = s.SlsperId
where rtrim(i.user5) = '1' and s.SlsperId is null

Delete s from salesperson s inner join deleted d on d.custID = s.SlsperId 
inner join inserted ins on d.custID = ins.custID
where ins.User5 <> '1'

Delete s from Slsperhist S inner join deleted d on d.custID = s.SlsperId 
inner join inserted ins on d.custID = ins.custID
where ins.User5 <> '1'

Update C set SlsperId = case when rtrim(i.User5) = '1' then i.CustID 
                             else ''
                        end
from Customer C 
inner join Inserted i on c.CustID = i.CustID and (i.custID = i.SlsperId or rtrim(i.User5) = '1')

Update A set SlsperId = case when rtrim(i.User5) = '1' then i.CustID 
                             when (rtrim(i.User5) <> '1' and r.SlsperId is Null) then ''
                             else r.SlsperId
                        end
from Inserted I inner join soaddress A on I.CustID = a.CustID
left join xswpjpcustomer p on p.custID = A.CustID and p.shiptoid = a.ShiptoID
left join xswslsroute r on r.slsrouteID = p.slsrouteID

End
go

