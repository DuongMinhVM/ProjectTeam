
Create Trigger tr_Delete_SalesPerson
On
SalesPerson
For DELETE
AS
If Exists(Select * from Deleted)
Begin
	Declare @SiteCode as varchar(5)
	Select @SiteCode = value From fpt_MST_SS_Parameters
	Where ID = '005'

	Declare @SlsperID as varchar(10)
	Select @SlsperID = SlsperID from Deleted

	If  Not Exists (Select * From fpt_MST_SS_Data_Delete Where Code = Rtrim(@SiteCode)+Rtrim(@SlsperID) and DataType = 'SalePerson')
	Begin
		Insert Into fpt_MST_SS_Data_Delete						
		Values (@SiteCode,'SalePerson',Getdate(),Rtrim(@SiteCode)+Rtrim(@SlsperID) ,0,0,'',Rtrim(@SlsperID),'','','','')
	End
	Else
	Begin
		Update fpt_MST_SS_Data_Delete Set Status = 0 Where Code = Rtrim(@SiteCode)+Rtrim(@SlsperID)		
	End
	Update fpt_MST_SS_Data_Baseline Set ProcessType = 'DataDelete' Where Code = Rtrim(@SiteCode)+Rtrim(@SlsperID) and Status <>2
End
go

