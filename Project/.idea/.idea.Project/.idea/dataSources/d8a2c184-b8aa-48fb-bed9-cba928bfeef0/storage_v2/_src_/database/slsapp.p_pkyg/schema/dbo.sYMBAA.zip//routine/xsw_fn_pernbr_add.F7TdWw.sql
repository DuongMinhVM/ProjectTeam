
create function xsw_fn_pernbr_add (@pernbr char(6), @add smallint)
RETURNS char(6) AS BEGIN 
declare @year int
declare @month int
declare @syear char(4)
declare @smonth char(2)
declare @new char(6)
declare @x int
declare @base int

select top 1 @base = NbrPer from GLSetup (nolock)

set @syear = left(@pernbr, 4)
set @smonth = substring(@pernbr, 5, 2)

if isnumeric(@syear) != 1 or isnumeric(@smonth) != 1 or @base is null or @base <= 0 goto finish

set @year = convert(int, @syear)
set @month = convert(int, @smonth)

set @x = @year * @base + @month - 1 + @add

if @x < 0 goto finish

set @year = @x / @base
set @month = ( @x % @base ) + 1

set @syear  = right('0000' + ltrim(str(@year, 4, 0)), 4)
set @smonth = right('00' + ltrim(str(@month, 2, 0)), 2)

set @new = @syear + @smonth

if isnumeric(@new) = 1 set @pernbr = @new

finish:

return @pernbr
END
go

