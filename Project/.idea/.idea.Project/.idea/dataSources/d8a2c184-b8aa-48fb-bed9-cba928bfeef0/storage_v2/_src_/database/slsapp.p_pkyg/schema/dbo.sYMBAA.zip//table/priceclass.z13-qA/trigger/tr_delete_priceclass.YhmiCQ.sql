
Create Trigger tr_Delete_PriceClass
On
PriceClass
For DELETE
AS
If Exists(Select * from Deleted)
Begin
	Declare @SiteCode as varchar(5)
	Select @SiteCode = value From fpt_MST_SS_Parameters
	Where ID = '005'

	Declare @PriceClassID as varchar(10)
	Declare @PriceClassType as varchar(10)
	Select @PriceClassID = PriceClassID, @PriceClassType = PriceClassType from Deleted

	If  Not Exists (Select * From fpt_MST_SS_Data_Delete Where Code = Rtrim(@SiteCode)+Rtrim(@PriceClassID)+'$'+Rtrim(@PriceClassType) and DataType in ('PriceClassI','PriceClassC'))
	Begin
		Insert Into fpt_MST_SS_Data_Delete						
		Values (@SiteCode,'PriceClass'+ @PriceClassType,Getdate(),Rtrim(@SiteCode)+Rtrim(@PriceClassID)+'$'+Rtrim(@PriceClassType),0,0,'',Rtrim(@PriceClassID),Rtrim(@PriceClassType),'','','')
	End
	Else
	Begin
		Update fpt_MST_SS_Data_Delete Set Status = 0 Where Code = Rtrim(@SiteCode)+Rtrim(@PriceClassID)+'$'+Rtrim(@PriceClassType)
	End
	Update fpt_MST_SS_Data_Baseline Set ProcessType = 'DataDelete' Where Code = Rtrim(@SiteCode)+Rtrim(@PriceClassID)+'$'+Rtrim(@PriceClassType) and Status <>2
End
go

