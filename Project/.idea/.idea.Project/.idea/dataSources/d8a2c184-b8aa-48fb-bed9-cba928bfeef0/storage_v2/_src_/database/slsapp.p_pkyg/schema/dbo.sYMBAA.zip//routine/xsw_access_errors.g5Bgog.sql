
create function xsw_access_errors (@retcode int)
	returns varchar(255)
begin 

return case @retcode
	when  0 then ''
	when  1 then 'Error: Database is in use. Please close all Solomon screens and log off from Solomon first.'
	when  2 then 'Critical Error: Cannot determine system database name.'
	when  3 then 'Unexpected SQL Error (retcode=3).'
	when  4 then 'Unexpected Error (retcode=4).'
	when  5 then 'Critical Error: Access table is gone.'
	when  6 then 'Critical Error: xswTempAccess table is gone.'
	when  7 then 'Critical Error: xswTempAccess table already exists.'
	when  8 then 'Critical Error: Access table already exists.'
	when  9 then 'SQL error when renaming Access table.'
	when 10 then 'SQL error when renaming xswTempAccess table.'
	else 'Unexpected Error (unknown retcode).'
end

end
go

