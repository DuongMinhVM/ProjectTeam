
Create Trigger tr_Update_xswCusthierarchy
On
xswCusthierarchy
For UPDATE,INSERT
AS
If (Update(NodeID01) OR  Update(NodeID02) OR Update(NodeID04))
Begin
	Declare @CustID as varchar(10)
	Declare @ShiptoID as varchar(5)
	Select @CustID=CustID, @ShiptoID=ShipToID from Inserted
	
	Update xswCusthierarchy set user4 = 0
	Where CustID = @CustID and ShipToID = @ShiptoID	
	
End
go

