
create function fnMUOMizFloat (@invtid varchar(30), @qty float, @uom varchar(6) = '') 
	RETURNS varchar(15)
BEGIN 

DECLARE @retval varchar(15) 

if isnull(@uom, '') = '' SELECT @uom = UOM1 FROM xswInvtConvUnit WHERE InvtID = @invtid

SELECT @uom = UOM1 FROM xswInvtConvUnit WHERE InvtID = @invtid AND UOM1 <> @uom AND UOM2 <> @uom AND UOM3 <> @uom

SELECT @qty = CASE @uom 
	WHEN UOM3 THEN @qty * CnvFact3 
	WHEN UOM2 THEN @qty * CnvFact2 
	WHEN UOM1 THEN @qty * CnvFact1 
	ELSE @qty END 
FROM xswInvtConvUnit WHERE InvtID = @invtid

SELECT TOP 1 @retval = 
	CASE WHEN @qty < 0 THEN '-' ELSE '' END + 
	CASE WHEN UOM3 = '' THEN '' ELSE 
		convert(varchar, convert(int, floor(abs(@qty) / CnvFact3))) + 
		CASE WHEN UOM3 = @UOM THEN '' ELSE '/' END 
	END + 
	CASE WHEN (UOM2 = '' or UOM3 = @uom) THEN '' ELSE 
		convert(varchar, convert(int, floor((abs(@qty) - 
			CASE WHEN UOM3 = '' THEN 0 ELSE CnvFact3 * floor(abs(@qty) / CnvFact3) END) / 
			CnvFact2))) + 
		CASE WHEN UOM2 = @uom THEN '' ELSE '/' END 
	END + 
	CASE WHEN (UOM1 = '' or UOM3 = @uom or UOM2 = @uom) THEN '' ELSE 
		convert(varchar, convert(int, floor((abs(@qty) - 
			CASE WHEN UOM2 = '' THEN 0 ELSE CnvFact2 * floor(abs(@qty) / CnvFact2) END) / 
			CnvFact1))) + 
		CASE WHEN UOM1 = @uom THEN '' ELSE '/' END 
	END + 
	CASE WHEN (UOM1 = UOM or UOM3 = @uom or UOM2 = @uom or UOM1 = @uom) THEN '' ELSE 
		convert(varchar, convert(int, floor((abs(@qty) - 
			CASE WHEN UOM1 = '' THEN 0 ELSE CnvFact1 * floor(abs(@qty) / CnvFact1) END))))
	END
FROM xswInvtConvUnit WHERE InvtID = @invtid

if @retval = '' set @retval = convert(varchar(15), @qty) 

RETURN @retval

END
go

