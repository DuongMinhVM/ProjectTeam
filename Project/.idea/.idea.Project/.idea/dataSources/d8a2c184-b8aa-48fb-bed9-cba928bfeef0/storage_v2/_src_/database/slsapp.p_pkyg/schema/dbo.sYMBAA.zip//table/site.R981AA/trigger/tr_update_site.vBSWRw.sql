
Create Trigger tr_Update_Site
On
Site
For UPDATE,INSERT
AS
If (Update(Name) OR Update(user1) OR Update(user5) OR Update(attn) OR Update(salut) OR Update(addr1) 
	OR Update(addr2) OR Update(DfltRepairBin) OR Update(DfltVendorBin))
Begin
	Update Site set User4 = 0
	Where SiteID in (Select SiteID from Inserted)
End
go

