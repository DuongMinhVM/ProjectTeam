
Create trigger tr_Update_Salesperson
On
Salesperson
For UPDATE,INSERT
AS
If (Update(Name) OR Update(Addr1) OR Update(Addr2) OR Update(City) OR Update(State) OR Update(Zip)
	OR Update(Country) OR Update(Phone) OR Update(Fax) OR Update(EmailAddr) OR Update(User1) OR Update(User2))
Begin
	Update Salesperson Set s4future10 = 0
	Where SlsperID in (Select SlsperID from Inserted)
End
go

