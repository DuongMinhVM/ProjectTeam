
Create Trigger tr_Update_SOAddress
On
SOAddress
For UPDATE,INSERT
AS
Begin
	Declare @CustID as varchar(10)
	Declare @ShiptoID as varchar(5)
	If  Exists (Select * from xswPJPCustomer Where User4 =0)
	Begin
		Select @CustID=CustID, @ShiptoID=ShipToID From xswPJPCustomer Where User4 =0
	
		Update SOAddress set User4 = 0
		Where CustID = @CustID and ShipToID = @ShiptoID		
		
		Update xswPJPCustomer set User4 = 2 Where User4 = 0	
	End
	If   Exists (Select * from xswCusthierarchy Where user4 =0)
	Begin
		Select @CustID=CustID, @ShiptoID=ShipToID From xswPJPCustomer Where User4 =0
	
		Update SOAddress set User4 = 0
		Where CustID = @CustID and ShipToID = @ShiptoID		
		
		Update xswPJPCustomer set User4 = 2 Where User4 = 0	
	End

	If (Update(ShipToID) OR  Update(User5) OR Update(descr) OR Update(Addr1) OR Update(Addr2) OR Update(Name) 
	OR Update(City)OR Update(Country) OR Update(SlsPerID) )
	Begin
		
		Select @CustID=CustID, @ShiptoID=ShipToID from Inserted
	
		Update SOAddress set user4 = 0
		Where CustID = @CustID and ShipToID = @ShiptoID		
	End
End
go

