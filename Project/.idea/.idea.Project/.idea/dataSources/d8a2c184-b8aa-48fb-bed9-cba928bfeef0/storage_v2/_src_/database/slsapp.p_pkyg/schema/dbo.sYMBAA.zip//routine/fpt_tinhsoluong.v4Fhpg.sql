
CREATE FUNCTION fpt_TinhSoLuong
/*Tinh tong so luong hang ma khach hang da mua trong khoang thoi gian nao do
	- Cac tham so truyen vao:
		+ Khoang thoi gian From_Date, To_date
		+ Ma khach hang
		+ Ma chuong trinh luy ke
	- Gia tri tra ve:
		+ la mot so kieu int
	Author:			Vu Dinh Cuong
	Created date:	28 - Mar - 2007
*/
	(
	@Customer_ID char(15),@ACC_ID varchar(13),
	@From_Date Datetime, @To_Date datetime
	)
RETURNS INT
AS
BEGIN

DECLARE @retVal int
-- LAY TONG SO LUONG MA KHACH HANG DA MUA TRU DI SO LUONG KHACH TRA LAI
set @retVal = (SELECT  SUM(CASE WHEN OrderType IN ('CI', 'IN', 'NP', 'NI') Then LineQty ELSE -1*LineQty end)
	FROM         xswSlsOrdDet
	WHERE    FREEITEM <> 1 AND (CustId = @Customer_ID) AND (OrderDate BETWEEN @From_Date AND @To_date) 
			AND (InvtId IN (select Item_ID from fpt_ShellProduct  where Acc_ID = @ACC_ID)))
IF (@retVal IS NULL)
	SET @retVal = 0
RETURN @retVal
END


go

